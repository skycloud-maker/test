﻿from pathlib import Path
import csv,json,hashlib,difflib
B=Path('voc-migration-audit-20261028');N=B/'extracted/new/Ver2_한줄흐름';O=B/'old_tool_sources/VoC_1_전체통합';rows=[];newfiles=[(p,p.read_bytes().replace(b'\r\n',b'\n')) for p in (N/'plugin').rglob('*') if p.is_file()]
for category in ['스크립트','프롬프트','정본']:
 for old in sorted((O/category).glob('*')):
  if not old.is_file():continue
  blob=old.read_bytes().replace(b'\r\n',b'\n');matches=[p for p,b in newfiles if p.name==old.name]
  equal=[p for p,b in newfiles if p in matches and b==blob]
  # renamed standards: hash-match every new file, exact LF bytes
  if not equal:equal=[p for p,b in newfiles if p.suffix==old.suffix and b==blob]
  rows.append({'category':category,'old':old.relative_to(O).as_posix(),'status':'LF 동일' if equal else '동명 파일 내용 차이' if matches else '동명·동일 내용 대응 없음','new_matches':' | '.join(p.relative_to(N).as_posix() for p in (equal or matches))})
(B/'old_primary_41_file_coverage.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
with (B/'old_primary_41_file_coverage.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
print('TOTAL',len(rows));print('NO DIRECT MATCH')
for r in rows:
 if not r['new_matches']:print(r['old'])
