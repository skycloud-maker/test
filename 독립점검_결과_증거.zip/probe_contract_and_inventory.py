﻿from pathlib import Path
import shutil,subprocess,sys,os,json,ast,collections
B=Path(__file__).resolve().parent;N=B/'extracted/new/Ver2_한줄흐름';run=B/'probe_runs/pl_invalid_schema';run.mkdir(parents=True,exist_ok=True);tool=run/'PL이슈_뽑기.py';shutil.copy2(N/'plugin/shared/tools/PL이슈_뽑기.py',tool);raw=run/'_판독패키지/_결과/master_final/raw_voc.csv';raw.parent.mkdir(parents=True,exist_ok=True);raw.write_text('atomic_id,wrong_column\np-001,synthetic\n',encoding='utf8')
p=subprocess.run([sys.executable,'-B',str(tool)],cwd=str(run),env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1'),capture_output=True,text=True,encoding='utf8',errors='replace');(B/'pl_schema_probe.json').write_text(json.dumps({'exit_code':p.returncode,'input_columns':['atomic_id','wrong_column'],'output_exists':(raw.parent/'PL이슈.csv').exists(),'log':p.stdout+p.stderr},ensure_ascii=False,indent=2),encoding='utf8');print('PL_MALFORMED_INPUT_EXIT',p.returncode)
F=json.loads((N/'대조장치/얼린기준_목록.json').read_text(encoding='utf8'));print('FROZEN',[(k,v['파일수'],len(v['파일'])) for k,v in F.items()]);print('TOTAL',sum(v['파일수'] for v in F.values()))
print('SKILLS')
for p in sorted((N/'plugin/skills').glob('*/SKILL.md')):print(p.parent.name,'lines',len(p.read_text(encoding='utf8').splitlines()))
print('EVAL_DESCRIPTIONS')
for p in sorted((N/'plugin/skills').glob('*/evals/evals.json')):
 d=json.loads(p.read_text(encoding='utf8'));print(p.parents[1].name, d.get('설명','')[:420])
