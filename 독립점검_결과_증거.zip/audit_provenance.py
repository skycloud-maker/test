﻿from pathlib import Path,PurePosixPath
from zipfile import ZipFile
from io import BytesIO
import hashlib,json,collections
B=Path(__file__).resolve().parent;N=B/'extracted/new/Ver2_한줄흐름';O=B/'extracted/original/원본_바탕자료';R=B/'extracted/redacted/원본_바탕자료'
h=lambda b:hashlib.sha256(b).hexdigest()
def files(root):return {p.relative_to(root).as_posix():p.read_bytes() for p in root.rglob('*') if p.is_file()}
o,r=files(O),files(R);result={'redaction':{'added':sorted(set(r)-set(o)),'removed':sorted(set(o)-set(r)),'changed':[p for p in o.keys()&r.keys() if o[p]!=r[p]],'same':sum(o[p]==r[p] for p in o.keys()&r.keys())}}
p='배포꾸러미_원본/VoC_1_전체통합.zip'
with ZipFile(BytesIO(o[p])) as zo,ZipFile(BytesIO(r[p])) as zr:
 of={x.filename:zo.read(x) for x in zo.infolist() if not x.is_dir()};rf={x.filename:zr.read(x) for x in zr.infolist() if not x.is_dir()};result['redaction']['inner']={'old_count':len(of),'new_count':len(rf),'removed':{x:{'bytes':len(of[x]),'sha256':h(of[x])} for x in of.keys()-rf.keys()},'added':sorted(rf.keys()-of.keys()),'changed':[x for x in of.keys()&rf.keys() if of[x]!=rf[x]],'outer_original_sha256':h(o[p])}
# Recursively index originals, retaining only names/hashes in report.
index=[]
def visit(blob,name,depth=0):
 if name.lower().endswith('.zip') and depth<5:
  with ZipFile(BytesIO(blob)) as z:
   for i in z.infolist():
    if not i.is_dir():visit(z.read(i),name+'!/'+i.filename,depth+1)
 else:index.append((name,blob))
for name,blob in o.items():visit(blob,name)
by_hash=collections.defaultdict(list)
for name,blob in index:by_hash[h(blob)].append(name)
def norm(blob):return blob.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
by_lf=collections.defaultdict(list)
for name,blob in index:by_lf[h(norm(blob))].append(name)
records=[]
for mf,engine in [('plugin/shared/출처_꾸러미.json',False),('plugin/engine/출처_엔진.json',True)]:
 manifest=json.loads((N/mf).read_text(encoding='utf8'))['파일']
 for rel,rec in manifest.items():
  path=N/'plugin/engine'/rel if engine else N/rel;b=path.read_bytes() if path.is_file() else b''
  orig_matches=by_hash.get(rec['원본_sha256'],[]);lfmatches=by_lf.get(rec['원본_sha256'],[])
  exactold=by_hash.get(h(b),[]);normold=by_lf.get(h(norm(b)),[])
  records.append({'manifest':mf,'path':path.relative_to(N).as_posix(),'exists':path.is_file(),'current_hash_ok':h(b)==rec['지금_sha256'],'declared_original_hash_matches':orig_matches,'declared_original_lf_matches':lfmatches,'new_raw_equal_old':exactold,'new_lf_equal_old':normold,'original_equals_current_manifest':rec['원본_sha256']==rec['지금_sha256'],'history_count':len(rec.get('고친_이력',[]))})
result['provenance']=records;result['summary']={'records':len(records),'missing':sum(not x['exists'] for x in records),'current_hash_mismatch':sum(not x['current_hash_ok'] for x in records),'original_declared_hash_unlocated':sum(not x['declared_original_hash_matches'] and not x['declared_original_lf_matches'] for x in records),'new_without_old_lf_equivalent':sum(not x['new_raw_equal_old'] and not x['new_lf_equal_old'] for x in records),'manifest_changed_without_history':sum(not x['original_equals_current_manifest'] and x['history_count']==0 for x in records)}
# Extract only non-result members for tool/role inspection; raw CSV/xlsx stay in original nested archive.
for zpath in (O/'배포꾸러미_原本').glob('*.zip'):pass
for zp in (O/'배포꾸러미_원본').glob('*.zip'):
 with ZipFile(zp) as z:
  for i in z.infolist():
   if i.is_dir():continue
   name=i.filename.replace('\\','/');pp=PurePosixPath(name)
   if '..' in pp.parts or name.startswith('/') or any(':' in x for x in pp.parts):raise ValueError(name)
   if any(x in ('결과','히스토리','꾸러미') for x in pp.parts) or name.endswith('.zip'):continue
   dest=B/'old_tool_sources'/zp.stem/Path(*pp.parts);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(i))
(B/'provenance_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(result['redaction'],ensure_ascii=False,indent=2));print(json.dumps(result['summary'],ensure_ascii=False));print('NONMATCHING_CURRENT')
for x in records:
 if not x['new_raw_equal_old'] and not x['new_lf_equal_old']:print(x['path'])
