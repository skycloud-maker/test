﻿from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
import json,hashlib,collections,difflib
B=Path(__file__).resolve().parent;N=B/'extracted/new/Ver2_한줄흐름';O=B/'extracted/original/원본_바탕자료';h=lambda b:hashlib.sha256(b).hexdigest();index=[]
def visit(b,n,depth=0):
 if n.endswith('.zip') and depth<6:
  with ZipFile(BytesIO(b)) as z:
   for i in z.infolist():
    if not i.is_dir():visit(z.read(i),n+'!/'+i.filename,depth+1)
 else:index.append((n,b))
for p in O.rglob('*'):
 if p.is_file():visit(p.read_bytes(),p.relative_to(O).as_posix())
result=[];diffs=B/'evidence_diffs';diffs.mkdir(exist_ok=True)
for manifest,engine in [('plugin/shared/출처_꾸러미.json',False),('plugin/engine/출처_엔진.json',True)]:
 for rel,r in json.loads((N/manifest).read_text(encoding='utf8'))['파일'].items():
  p=N/'plugin/engine'/rel if engine else N/rel;b=p.read_bytes();same=[];variants=[];names=[]
  for name,old in index:
   if Path(name).name==p.name:names.append((name,old))
   lf=old.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
   if b.replace(b'\r\n',b'\n').replace(b'\r',b'\n')==lf:same.append(name)
   if r['원본_sha256'] in {h(old),h(lf),h(lf.replace(b'\n',b'\r\n'))}:variants.append(name)
  status='raw_or_LF_equal' if same else 'different_named_source' if names else 'not_in_supplied_original'
  entry={'path':p.relative_to(N).as_posix(),'group':'engine' if engine else 'materials','status':status,'original_hash_matches_with_lineending_variants':variants,'equivalent_sources':same,'same_name_sources':[n for n,_ in names],'history':r.get('고친_이력',[])};result.append(entry)
  if status=='different_named_source' and p.suffix in ['.md','.py','.json']:
   oldname,old=max(names,key=lambda z:difflib.SequenceMatcher(None,z[1],b).ratio());oldtext=old.decode('utf-8-sig',errors='replace').splitlines();newtext=b.decode('utf-8-sig',errors='replace').splitlines()
   diff='\n'.join(difflib.unified_diff(oldtext,newtext,fromfile=oldname,tofile=entry['path'],n=3));(diffs/(('engine_' if engine else 'shared_')+p.name+'.diff')).write_text(diff,encoding='utf8')
(B/'independent_source_matches.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
for group in ['materials','engine']:
 aa=[x for x in result if x['group']==group];print(group,len(aa),dict(collections.Counter(x['status'] for x in aa)),'declared original match variants',sum(bool(x['original_hash_matches_with_lineending_variants']) for x in aa))
print('changed sources')
for x in result:
 if x['status']=='different_named_source':print(x['path'],'history',len(x['history']))

