﻿from pathlib import Path
import importlib.util,sys,json,tempfile,ast
from openpyxl import Workbook
B=Path(__file__).resolve().parent;N=B/'extracted/new/Ver2_한줄흐름';sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('audit_comparator',N/'대조장치/맞대기.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
results=[];root=B/'probe_runs';root.mkdir(exist_ok=True)
def case(name,expected_detect,setup):
 with tempfile.TemporaryDirectory(dir=root) as td:
  a,b=Path(td)/'a',Path(td)/'b';a.mkdir();b.mkdir();setup(a,b);dif=m.맞대기(a,b);results.append({'case':name,'expected_detect':expected_detect,'detected':bool(dif),'observed':dif[:3]})
def text(a,b,x,y,filename='a.csv'):(a/filename).write_text(x,encoding='utf8'),(b/filename).write_text(y,encoding='utf8')
def excel(a,b,rowsa,rowsb,style=False):
 for p,rows in [(a,rowsa),(b,rowsb)]:
  w=Workbook();w.active.title='data'
  for row in rows:w.active.append(row)
  if style and p==b:
   from openpyxl.styles import PatternFill
   w.active['A2'].fill=PatternFill('solid',fgColor='FF0000')
  w.save(p/'a.xlsx')
case('missing_directory_fails',True,lambda a,b:None) # empty-directory guard below, missing separately
results[-1]['case']='two_empty_directories_fail'
case('ordinary_csv_value_change',True,lambda a,b:text(a,b,'id,value\n1,old\n','id,value\n1,new\n'))
case('ordinary_xlsx_value_change',True,lambda a,b:excel(a,b,[['id','value'],['1','old']],[['id','value'],['1','new']]))
case('xlsx_formula_change_without_cached_values',True,lambda a,b:excel(a,b,[['id','calc'],['1','=1+1']],[['id','calc'],['1','=100+100']]))
case('xlsx_style_change',True,lambda a,b:excel(a,b,[['id','v'],['1',2]],[['id','v'],['1',2]],True))
case('timestamp_row_other_text_change',True,lambda a,b:excel(a,b,[['편향검사','규칙 A 2026-10-01 10:00']],[['편향검사','규칙 B 2026-10-01 10:00']]))
case('timestamp_csv_other_column_change',True,lambda a,b:text(a,b,'잰_날짜,2026-10-01 10:00,관측일,2025-01-01 12:00\n','잰_날짜,2026-10-01 10:00,관측일,2025-02-01 12:00\n'))
case('invalid_utf8_distinct_bytes',True,lambda a,b:((a/'a.txt').write_bytes(b'\xff'),(b/'a.txt').write_bytes(b'\xfe')))
case('ordinary_timestamp_only_normalized',False,lambda a,b:text(a,b,'잰_날짜,2026-10-01 10:00\n','잰_날짜,2026-10-02 11:00\n'))
case('corrupt_xlsx_fails',True,lambda a,b:((a/'a.xlsx').write_bytes(b'bad'),(b/'a.xlsx').write_bytes(b'bad')))
case('one_sided_file_detected',True,lambda a,b:(a/'a.md').write_text('only',encoding='utf8'))
# Execute the two supplied comparator-only tests without importing missing full test harness.
tree=ast.parse((N/'대조장치/test_baseline.py').read_text(encoding='utf8'))
selected=['test_맞대기가_다름을_잡는다','test_허용한_칸만_빼고_나머지는_잡는다'];supplied=[]
for fn in tree.body:
 if isinstance(fn,ast.FunctionDef) and fn.name in selected:
  ns={'맞대기':m.맞대기,'맞대기_mod':m};exec(compile(ast.Module(body=[fn],type_ignores=[]),str(N/'대조장치/test_baseline.py'),'exec'),ns)
  with tempfile.TemporaryDirectory(dir=root) as td:
   try:ns[fn.name](*([Path(td)] if fn.args.args else []));supplied.append({'name':fn.name,'pass':True})
   except Exception as e:supplied.append({'name':fn.name,'pass':False,'error':repr(e)})
missing=m.맞대기(root/'not_exist',root);results.append({'case':'missing_directory_fails','expected_detect':True,'detected':bool(missing),'observed':missing})
output={'independent_cases':results,'supplied_comparator_tests_executed':supplied,'missed_changes':[x['case'] for x in results if x['expected_detect'] and not x['detected']]}
(B/'comparator_probe_results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(output,ensure_ascii=False,indent=2))
