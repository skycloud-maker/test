﻿from pathlib import Path
import subprocess,sys,os,json,hashlib,re
from zipfile import ZipFile
B=Path(__file__).resolve().parent;N=B/'extracted/new/Ver2_한줄흐름';S=N/'plugin/skills';run=B/'smoke_runs';run.mkdir(exist_ok=True);env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',PYTHONUTF8='1');records=[]
def execute(name,args,timeout=120):
 p=subprocess.run([sys.executable,'-B',*map(str,args)],cwd=str(run),env=env,capture_output=True,text=True,encoding='utf8',errors='replace',timeout=timeout)
 (run/(name+'.log')).write_text(p.stdout+'\nSTDERR\n'+p.stderr,encoding='utf8');rec={'test':name,'exit_code':p.returncode,'log':str((run/(name+'.log')).relative_to(B))};records.append(rec);print(name,p.returncode,flush=True);return p
execute('reader_setup',[S/'reading-voc-comments/scripts/판독폴더_차리기.py',run/'reader'])
execute('supervisor_setup',[S/'supervising-voc-disagreements/scripts/감독폴더_차리기.py',run/'supervisor'])
execute('coordinator_setup',[S/'coordinating-voc-pipeline/scripts/총괄자리_차리기.py',run/'coordinator','audit'])
execute('coordinator_setup_again',[S/'coordinating-voc-pipeline/scripts/총괄자리_차리기.py',run/'coordinator','audit'])
execute('preview_no_approval',[S/'coordinating-voc-pipeline/scripts/한줄_돌리기.py',run/'preview','--확인만'])
# Locally supplied original workbook: no upload, no AI, no external API.
zp=B/'extracted/original/원본_바탕자료/배포꾸러미_원본/VoC_1_전체통합.zip';inp=run/'private_input';inp.mkdir(exist_ok=True)
with ZipFile(zp) as z:
 target='결과/voc_dashboard_export_bundle_2차시험본.xlsx';data=z.read(target);p=inp/'original_final.xlsx';p.write_bytes(data)
for i in [1,2]:execute('report_'+str(i),[S/'building-voc-report/scripts/보고서_만들기.py',p,run/('report_'+str(i)+'.html')],timeout=180)
r1,r2=run/'report_1.html',run/'report_2.html';report_compare={'output_exists':r1.exists() and r2.exists(),'input_sha256':hashlib.sha256(data).hexdigest()}
if report_compare['output_exists']:
 aa,bb=r1.read_text(encoding='utf8'),r2.read_text(encoding='utf8');pat=r'만든 날</b> \d{4}-\d{2}-\d{2} \d{2}:\d{2}';report_compare.update({'timestamps_a':len(re.findall(pat,aa)),'timestamps_b':len(re.findall(pat,bb)),'equal_except_creation_minute':re.sub(pat,'만든 날</b> [때]',aa)==re.sub(pat,'만든 날</b> [때]',bb),'bytes_a':r1.stat().st_size,'bytes_b':r2.stat().st_size})
(B/'smoke_results.json').write_text(json.dumps({'commands':records,'report_reproducibility':report_compare},ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(report_compare,ensure_ascii=False))
