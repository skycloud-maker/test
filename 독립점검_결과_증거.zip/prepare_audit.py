﻿from pathlib import Path,PurePosixPath
from zipfile import ZipFile
import json,hashlib
B=Path(__file__).resolve().parent
inputs={'original':Path('D:/Downloads/원본_바탕자료.zip'),'redacted':Path('D:/Downloads/점검용_원본바탕자료.zip'),'new':Path('D:/Downloads/Ver2_한줄흐름.zip')}
manifest={}
for key,p in inputs.items():
 dest=B/'extracted'/key;dest.mkdir(parents=True,exist_ok=True)
 with ZipFile(p) as z:
  files=[i for i in z.infolist() if not i.is_dir()];print(key,len(files),sum(i.file_size for i in files));print('\n'.join(i.filename for i in files[:15]))
  for i in z.infolist():
   name=i.filename.replace('\\','/');parts=PurePosixPath(name).parts
   if name.startswith('/') or any(x in ['..'] for x in parts) or any(':' in x for x in parts):raise ValueError(name)
   target=dest.joinpath(*parts)
   if i.is_dir():target.mkdir(parents=True,exist_ok=True)
   else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(i))
 manifest[key]={'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'file_count':len(files),'uncompressed_bytes':sum(i.file_size for i in files)}
(B/'archive_inventory.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
