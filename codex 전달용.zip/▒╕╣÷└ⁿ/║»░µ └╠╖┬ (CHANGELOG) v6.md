# 변경 이력 (CHANGELOG) v6

## 🔵 가장 최근 — 2026-07-31 (대시보드 그린필드 Phase 1+2 + 온라인 배포)
**핵심: 60컬럼 엔진이 실제 운영 대시보드로 연결되고, 온라인 배포까지 완료.**

- **대시보드 그린필드 결정** → 60컬럼 v2.4 엔진 출력 위 **새 운영앱**(`src/dashboard60`), 기존 모놀리스 `src/dashboard_app.py`는 **`app_admin.py`로 park**(삭제 아님). 진입점 `streamlit_app.py → dashboard60.app_operating`.
- **Phase 1**: `scripts/run_voc_rebuild_dashboard.py`(60컬럼 엔진→dataset) · `data_contract.py`(로더+파생 sentiment_dir·cej_group(5)·validity·게이팅) · `app_operating.py`. 실데이터 렌더 확인.
- **Phase 2**: 운영 **3탭**(VoC 개요/드릴다운 · 영상 분석 요약 · 문의/정보접근 인사이트) · **모듈 분해**(views/overview·video·inquiry · gating · charts) · 테스트 **3 passed** · 스크린샷 3장 · **개선과제/전략 2차 이관**. Codex 커밋 `3e785ab`.
- **✅ 온라인 배포**: Streamlit Community Cloud, entrypoint `streamlit_app.py`, 커밋 fixture 소비(시크릿 불필요). **Live URL**: https://youtube-comment-analyzer-6mqt339a5yocl9ztw6hyak.streamlit.app/ — 회사에서 접속 가능. ⚠️ 공개 URL→뷰어 제한 권장. **기존 production·main 미변경.** (브랜치 push 시 자동 재배포됨)
- **신규 산출물**: 대시보드 개편 계획 v1 · Codex_대시보드파일요청 · Phase1/Phase2 빌드지시 · **Codex 표준 실행·검증 규칙** · 야간 무인 작업 지시서 v2 · 배포 가이드 · Phase2 보고서 · 핸드오프 v2.6/**v2.7**.
- **스킵/보류**: 실수집 OpenAI 실행(비용) · 유효성 놓침 23(엔진 캘리브레이션 → Cowork 검증 후) · topic 카테고리 택소노미(후속).

---

## 지난 변경 — 2026-07-30 (Step 0 + Round 5~7 + 문서 일괄 반영)
- 엔진 R5(blind토큰 제거·택소노미+3·CEJ 해당없음) → R6(미분류) → R7(N/A 우선·해당없음 완화·raw50 54→59 회복, `e54bbf6`).
- **Step 0(통합 가전 120건)**: 문의 95%·감성 78%(High 81)·CEJ 57%(High 74)·유효성 71%. → 제품 무관 필드 일반화, 게이팅 검증.
- **문서 일괄 반영**: 데이터사전 **v2.4** · 설계서 **v6**(변경 반영) · 정답지 **v2**(동선 rc3·청소신뢰성 tsc3·CEJ 해당없음) · 핸드오프 v2.5 · CHANGELOG v5 · Step0 최종 리포트 v2 · 문서 반영 대장.

## 지난 변경 — 2026-07-30 (Round 3·4 + Step 0 착수) / 2026-07-30 R2 / 07-29
R3 84/84(과적합·보류)→R4 tuple 제거(`4ff91fc`). Step0 자산·데이터사전 v2.3·계약 점검·핸드오프 v2.2~v2.4. / R2 LLM엔진(28/77)·설계서 v5.2. / 07-29 설계서 v3~v5.1·데이터사전 v2~v2.2·통합 데이터셋·Atomic 재정의·topic QA.

---

## 파일별 현재 버전 (2026-07-31)
| 파일 | 버전 |
|---|---|
| 프로젝트 핸드오프 | **v2.7** (Live URL 포함) |
| 변경 이력 (CHANGELOG) | **v6** |
| VoC 데이터 사전 (스키마) | v2.4 |
| VoC 분석 엔진 재현 설계서 | v6 |
| VoC 검증 자료(정답지) | v2 |
| 대시보드 | `src/dashboard60`(그린필드, **라이브**) · 엔진 `codex/voc-engine-rebuild` `3e785ab` |

## 이력 로그 (최신순)
- **2026-07-31** — 대시보드 그린필드 Phase 1+2 완료 + **온라인 배포(Live URL)**. CHANGELOG v6·핸드오프 v2.7.
- **2026-07-30 Step0+R5~7** — 통합 가전 신뢰도 확보, 문서 일괄 반영(데이터사전 v2.4·설계서 v6·정답지 v2).
- **2026-07-30 R3·R4·Step0 착수 / R2 / 07-29** — 84/84 보류·tuple 제거, Step0 자산, 엔진·설계서 초기 버전들.
