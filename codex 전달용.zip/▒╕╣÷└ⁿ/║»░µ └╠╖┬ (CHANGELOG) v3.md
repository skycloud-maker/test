# 변경 이력 (CHANGELOG) v3

> 파일명 버전은 올리되, **무엇이 언제 바뀌었는지는 이 파일 하나로** 추적합니다.
> "가장 최근 변경"만 다시 받으시면 됩니다.

---

## 🔵 가장 최근 변경 — 2026-07-30 (Codex Round-3 캘리브레이션 & 검증)
**이 4개를 새로 받으세요.**

| 파일 | 상태 | 내용 |
|---|---|---|
| `Round3_캘리브레이션_가이드.md` | 🆕 신규 | 캐노니컬 택소노미·정규화맵·N/A 규율·TEE/RootCause 앵커 + 정답지 FAIL 49 분류(expected→actual) |
| `Codex_Round3_교정메시지.md` | 🆕 신규 | Round-3 verbatim 교정 메시지 + 구현 스펙(7항) + 수용조건 체크리스트 |
| `프로젝트 핸드오프 (연속성 문서) v2.2.md` | ✏️ **v2.2** | Codex Round-1~3 라운드 이력 + Round-3 감사 결과 + Round-4 요청 반영 |
| `변경 이력 (CHANGELOG) v3.md` | ✏️ **v3** | (이 문서) |

**Round-3 검증 요지**: 정답지 84/84 PASS·홀드아웃 유지. 단 감사 결과 ①엔진 후처리에 정답지 케이스 토큰에 정답 튜플을 stamp하는 과적합 분기(동선·vague·회피력 원문-read·topic별 TEE 강제) ②84/84가 fresh LLM 재호출이 아닌 기존 raw output 재후처리 기준 → **원격 push 승인 보류 권고**, Round-4(fresh 재실행·ablation·분기 리팩터·blind holdout) 요청.

**미결**: 데이터사전 **v2.3(60컬럼 명시판)** 발행 검토 중 — 구조 변환 로직 타당, `confidence_score`(수치 vs rating) 1건만 택1 필요.

---

## 지난 변경 — 2026-07-30 (Codex Round-2 교정)
| 파일 | 상태 | 내용 |
|---|---|---|
| `Codex 교정 지시 (Round 2).md` | 🆕 신규 | '하드코딩 재현 엔진' 교정 — 실제 LLM 분석 엔진 재구현(홀드아웃 테스트·idx27 분리) |
| `VoC 분석 엔진 재현 설계서 (Codex 전달용).docx` | ✏️ **v5.2** | §4.3 정합(에코백스=단일 '가성비 문의', R9 일치) |
| `Codex 작업 지시서 (Build Brief).md` | ✏️ **v3.1** | §11 추가(하드코딩 금지·일반화되는 LLM 분석 엔진 필수) |

**Round-2 결과**: 실제 LLM 엔진 전환 성공(홀드아웃 7건 일반화). 정답지 exact 28/77 FAIL(로직 오류 아님·캘리브레이션 격차) → Round-3로 이어짐.

---

## 지난 변경 — 2026-07-29 밤 (설계서 TEE 4축 + 지시서 동기화)
| 파일 | 상태 | 내용 |
|---|---|---|
| `VoC 분석 엔진 재현 설계서 (Codex 전달용).docx` | ✏️ **v5.1** | §4.7 TEE를 4축(Time/Effort/Emotion/Success) 별도 표로 분리 |
| `Codex 작업 지시서 (Build Brief).md` | ✏️ **v3** | 완료기준을 설계서 v5.1에 동기화(Scoring·TEE 점수화·RC maturity·R1~R10) + §7 Fallback·§8 즉시구현·§9 커버리지·§10 Git(PR·수동병합) |

## 지난 변경 — 2026-07-29 밤 (Scoring 상세·TEE 렌즈·RC maturity)
| 파일 | 상태 | 내용 |
|---|---|---|
| `VoC 분석 엔진 재현 설계서 (Codex 전달용).docx` | ✏️ **v5** | §4.7 Scoring 상세기준 · §4.5 TEE '렌즈' · §4.6 RootCause maturity |
| `VoC 데이터 사전 (스키마).xlsx` | ✏️ **v2.2** | RootCause score를 maturity(L1·L2·L3) 라벨로 통일 |
| `VoC 검증 자료 (정답지) v1.xlsx` | ✏️ **v2.1** | 37-② Effort +3 근거 명시 |
| `VoC TEE·RootCause·Scoring 시범.xlsx` | ✏️ **v2.1** | 37-② Effort +3 근거 명시 |

## 지난 변경 — 2026-07-29 밤 (R1~R10 확정)
설계서 v4(§4.8 R1~R10), 데이터사전 v2.1('판정 규칙' 시트), 검증자료 v2(TEE·Scoring 정답 편입), 시범 v2.

## 지난 변경 — 2026-07-29 저녁 (Scoring 반영)
| 파일 | 상태 | 내용 |
|---|---|---|
| `VoC 분석 엔진 재현 설계서 (Codex 전달용).docx` | ✏️ **v3** | Scoring 섹션(§4.7) 신설, TEE −5~+5 점수화, Part C 점수 컬럼 |
| `VoC 데이터 사전 (스키마).xlsx` | ✏️ **v2** | score 컬럼 신설, 'Scoring 기준' 시트, self-QA 스코어 legacy |
| `VoC TEE·RootCause·Scoring 시범.xlsx` | 🆕 신규 | 대표 9건 점수 시범 + 스펙 점검 |

---

## 파일별 현재 버전 (2026-07-30 기준)
| 파일 | 현재 버전 | 비고 |
|---|---|---|
| `프로젝트 핸드오프 (연속성 문서).md` | **v2.2** | Round-1~3 이력·감사·Round-4 요청 |
| `변경 이력 (CHANGELOG).md` | **v3** | (이 문서) |
| `Round3_캘리브레이션_가이드.md` | v1 | 신규 |
| `Codex_Round3_교정메시지.md` | v1 | 신규 |
| `VoC 분석 엔진 재현 설계서 (Codex 전달용).docx` | v5.2 | Codex 전달본 |
| `VoC 데이터 사전 (스키마).xlsx` | v2.2(58행) | v2.3 60컬럼 명시판 검토 중 |
| `VoC 검증 자료 (정답지) v1.xlsx` | v1(정답지 v2.1 내용) | TEE·Scoring·ⓐ·6축 |
| `Codex 작업 지시서 (Build Brief).md` | v3.1 | 하드코딩 금지 §11 |
| Codex 산출물: `engine.py`(R3)·`validate_voc_engine_rebuild.py`·output/validation CSV·holdout·round3 report | 로컬 커밋 `bb9e652` | push 승인 대기 |

---

## 이력 로그 (최신순)
- **2026-07-30 (Round-3)** — 캘리브레이션 84/84 PASS. Cowork 감사: 과적합 후처리 분기·fresh-run 미실시 → push 보류·Round-4 요청. `Round3_캘리브레이션_가이드.md`·`Codex_Round3_교정메시지.md` 발행, 핸드오프 v2.2·CHANGELOG v3.
- **2026-07-30 (Round-2)** — 실제 LLM 엔진 전환·홀드아웃 성공, 정답지 28/77. 설계서 v5.2·지시서 v3.1.
- **2026-07-29 밤** — 설계서 v5.1(TEE 4축)·v5(Scoring 상세·RC maturity)·v4(R1~R10), 데이터사전 v2.2·v2.1.
- **2026-07-29 저녁** — 설계서 v3(Scoring §4.7·TEE −5~+5), 데이터사전 v2, 시범 신규.
- **2026-07-29 오후~** — 지시서 v2, 로직트리 매핑, 핸드오프 v2, 설계서 v2(CEJ 9단계·자사관점·미러열), 데이터사전 신설, 검증자료 신설.
- **2026-07-29 낮** — 통합 데이터셋 v1(raw50+6축 QA 38), 정합성 맵, Atomic 재정의 Before/After, topic HUMAN QA 52.

> 파일이 바뀔 때마다 이 이력 맨 위에 한 줄 추가하고 '가장 최근 변경' 표를 갱신합니다.
