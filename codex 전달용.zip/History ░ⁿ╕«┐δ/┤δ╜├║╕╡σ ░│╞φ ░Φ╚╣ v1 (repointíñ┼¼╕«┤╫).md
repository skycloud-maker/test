# 대시보드 개편 계획 v1 — repoint · 클리닝 · 게이팅
> 근거: 인벤토리 + `src/dashboard_app.py`(16k 모놀리스)·`config.py`·생성경로 확인 · 엔진↔대시보드 데이터 계약 점검 v1
> 전제: 대시보드는 **3개 분석 계보 혼재**(① front-stage 35컬럼 ② shadow/semantic nested ③ legacy parquet), **60컬럼 v2.4 엔진은 미연결**. → 목표 = **60컬럼 v2.4를 단일 canonical source로**.

## A. 데이터 계약 정합 (35컬럼/nested → 60컬럼 v2.4)
| 처리 | 항목 |
|---|---|
| **keep(동일)** | source_id · atomic_id · atomic_index · parent_voc_id · comment_relation · original_voc · atomic_voc · topic · product · brand · market · language · cej · status · review_required · topic_evidence · cej_evidence · source_context_summary · trace_summary · video_* |
| **rename/재구성** | `analysis_text`→**voc_cleaned**(+ atomic_voc_summary 신설) · `root_cause`(dict)→**rootcause_problem/target/cause/summary/score** · `tee_s`(dict)→**tee_time/effort/emotion/success_score(+evidence)** · `sentiment_label/final`→**TEE emotion/success에서 파생**(3-way) · `confidence_level`→**confidence_rating**(+ confidence_* 6) · `nlp_is_inquiry`/`inquiry_flag`→**inquiry_flag(+inquiry_type)** · `cej_scene_code`→**cej** |
| **new(60에 있고 대시보드에 없음)** | topic_score · reference_brand · competitor_product_* · **entity_role** · need_signal_flag/type · voc_total_score · proposal_flag · tee_*_evidence |
| **drop(35의 legacy 근거)** | atomic_evidence · product_evidence · competitor_evidence · confidence_atomic/product/competitor (v2.4 체계로 대체) |

## B. 생성 경로 스왑 (핵심)
- **현**: `run_raw_voc_openai_e2e_dashboard.py` → `openai_front_stage_parser`(35컬럼) → dashboard CSV.
- **목표**: 신규 `run_voc_rebuild_dashboard.py`(가칭) → **`src/voc_rebuild` 60컬럼 엔진**(`analyze_workbook_rows`) → **60컬럼 dashboard_dataset + topic_distribution** → 대시보드 소비.
- metadata `schema_version`: `front-stage-dashboard-v1` → **`voc-60col-v2.4`**, `parser_version`: `voc-rebuild-engine`.

## C. 탭 정리 (keep / park / delete / 승격)
| 탭 | 처리 |
|---|---|
| 댓글 VoC 대시보드 · 영상 분석 요약 · 문의/정보접근 인사이트 | **운영 유지 → 60컬럼 repoint** |
| 분석 Run 이력 · Dashboard Parity · 엔진 진단/보정 · 해석 엔진 진단 | **관리자·검증으로 분리 유지** |
| 개선과제/전략 후보 | **2차(별도 분석)로 이관** — 대시보드에서 덜어냄 |
| 새 해석 엔진 Preview | **60컬럼 운영으로 흡수 or 제거**(shadow/semantic 계보 정리) |

## D. 운영 화면 — 신뢰도 게이팅 (Step 0 반영)
- **우선 노출(신뢰 필드)**: 문의(95%) · 감성 방향(78/81%, TEE emotion·success 파생) · Topic 분포 · Entity Role.
- **보조**: CEJ(5그룹 집계·High confidence만) · Root Cause·TEE 세부는 드릴다운.
- **게이팅**: `confidence_rating` High만 기본 노출 + `review_required`/저신뢰 = **꼬리 사람검토 큐**. → 스토크홀더 수용 경로.
- **필터**: 제품군·브랜드·국가·CEJ(config에 이미 존재) → 전체 가전 특정 추출.

## E. 모놀리스 분해 (16k → 모듈)
`src/dashboard_app.py` → `data_contract.py`(60컬럼 로더·정규화 단일화) · `views/operating.py` · `views/admin.py` · `views/video.py` · `gating.py` · `app.py`(탭 조립). **3계보 정규화 로직을 data_contract 한 곳으로 수렴.**

## F. 실행 순서 (단계 · 각 단계 후 Step 0 게이팅 지표로 검증)
1. **데이터 계약 확정**(A·E): 60컬럼 로더 + 35/nested→60 정규화 매핑 모듈.
2. **생성 경로 스왑**(B): 60컬럼 엔진 → dashboard_dataset. (여기서 `openai_front_stage_parser.py` 있으면 정밀)
3. **운영 탭 repoint**(C·D): 메인·영상·문의 3탭을 60컬럼+게이팅으로.
4. **정리**: 개선과제·전략 2차 이관 · Preview/shadow/legacy park · 모놀리스 분해.

## 다음
- 이 계획 확정 → **Codex 빌드 지시서(Phase 1~2: 데이터 계약 + 생성경로 스왑)** 작성해 전달.
- (선택) `openai_front_stage_parser.py` 받으면 Phase 2를 더 정밀하게.
