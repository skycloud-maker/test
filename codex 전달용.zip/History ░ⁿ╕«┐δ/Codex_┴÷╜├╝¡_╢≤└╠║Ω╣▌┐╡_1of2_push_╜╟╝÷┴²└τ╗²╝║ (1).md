# Codex 지시서 — 라이브 반영 (1/2): draft push + 실수집 재생성 (★라이브 merge 전)

> **대상 브랜치**: `codex/taxonomy-redesign-draft`. **main / production 금지.**
> ★이 단계에선 **라이브 브랜치(`codex/voc-engine-rebuild`) merge / deploy / repoint 금지.** 준비 + Cowork 검증까지만. 실제 라이브 켜는 건 2단계.

## 작업
1. **draft push**: 택소노미 재설계 전체 변경분(`engine.py`·`schema.py`·`src/dashboard60/*`·`tests/*` + 이번 video-anchor 워킹트리 변경)을 선별 staging → commit → **push origin codex/taxonomy-redesign-draft**. (아직 로컬만 있는 video-anchor 변경 포함해 마무리)
2. **실수집 재생성(라이브 데이터)**: **실수집 로봇청소기 댓글 100~200건**(★**진짜 `video_title` 포함** — placeholder 아님. 신규 수집 또는 보유 processed run)으로 **새 엔진 재생성** → dashboard 데이터로 draft에 커밋.
   - LLM 배치: **백그라운드 + 25건마다 진행로그 + 넉넉한 하드타임아웃**, foreground로 붙잡지 말 것(막힌 것처럼 보여도 로그로 살아있는지만 확인). 승인 안 되면 멈추고 보고.
3. **dashboard60 렌더 확인**: 새 62컬럼(`product_category_source` 포함) 출력을 dashboard60가 문제없이 소비하는지 + 3탭 렌더 스크린샷(새 실데이터).
4. **★STOP**: 라이브 브랜치 merge / deploy / repoint **하지 말 것.** Cowork 검증 후 2단계에서.

## 보고
- product_category 분포(★real 제목이라 **로봇청소기 near-100%** 기대) + `product_category_source`(text/video) 분포
- topic(이유) 분포 · 로청 전용 발화율 · **제품-topic 오분류·과발화(0 기대)** · N/A/미분류율
- 행별 CSV + 3탭 스크린샷 + push 커밋 해시

## 제약 (하드)
- draft 브랜치 · **main·production·라이브 merge·deploy·repoint 금지** · 엔진/택소노미 로직 수정 금지(실행만) · 표준 실행 규칙.

→ Cowork가 실수집 재생성 결과 검증 → 통과 시 **2단계(merge + 배포 + 뷰어 제한)**.
