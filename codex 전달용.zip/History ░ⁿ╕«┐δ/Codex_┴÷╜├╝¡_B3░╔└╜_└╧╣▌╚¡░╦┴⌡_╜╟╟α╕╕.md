# Codex 지시서 — B 3걸음 일반화 검증 (★실행만, 튜닝 금지)

> **대상 브랜치**: `codex/taxonomy-redesign-draft` (현 draft 그대로). **라이브/main/deploy 금지.**
> 첨부: `로청 일반화검증 held-out 세트 (튜닝 미사용 19건).md`.

## 목적
3라운드 튜닝이 **같은 43건에만 맞춰진 건 아닌지(과적합)** 확인. 그래서 **튜닝에 안 쓴 새 19건**으로 **현 엔진을 그대로 실행**해 일반화를 본다.

## ★가장 중요한 제약 — 튜닝 절대 금지
- **engine.py를 포함해 어떤 규칙/프롬프트/alias/보호룰도 수정하지 말 것.** 현 상태 그대로 실행만.
- 결과가 나쁘게 나와도 **고치지 말고 그대로 보고.** (고치면 held-out 검증이 무의미해짐.)
- 새 코드/파일 생성 없이 **실행 + 산출물만**.

## 작업
1. 첨부 19건을 현 draft 엔진에 입력해 실행.
2. **행별 CSV** 제출: `comment · product_category · topic · cej · inquiry_flag · tee_emotion_score · confidence_rating · trace_summary`.
3. 요약: product_category 분포 · topic 분포 · 로청 전용 라벨 발화 건수 · N/A/미분류 비율.

## 판정
- 기대값/PASS는 **Cowork가** 함(첨부 md 하단 '기대'는 Codex에 주지 말 것). Codex는 순수 산출만.

## 제약
- 같은 draft 브랜치 · 라이브/main/deploy 금지 · **엔진 수정 금지** · 표준 실행 규칙(서버 detach·2분룰 미적용·재시도 2회·막히면 부분결과 보고).
- push는 사용량 제한 풀리면.

## 보고
19건 행별 CSV + 분포 요약. (engine diff 없음 — 이번엔 실행만.) → Cowork가 일반화 판정 → 통과 시 **B 최종 확정.**
