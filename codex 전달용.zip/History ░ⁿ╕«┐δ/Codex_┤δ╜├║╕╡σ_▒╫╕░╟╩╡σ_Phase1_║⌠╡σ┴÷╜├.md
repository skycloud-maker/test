# Codex 빌드 지시 — 대시보드 그린필드 Phase 1 (그대로 전달)

> 저장소: `skycloud-maker/youtube-comment-analyzer` · 브랜치: `codex/voc-engine-rebuild`
> 결정: **그린필드** — 60컬럼 v2.4 엔진 출력 위에 **새 운영 대시보드**를 짓고, 기존 `src/dashboard_app.py` 모놀리스는 **관리자/legacy로 park**(운영 기본에서 내림). **`openai_front_stage_parser.py`는 쓰지 않는다**(flag기반 TEE·dict confidence·CEJ enum 인코딩 깨짐 = 레거시).

## Phase 1 산출 (3개)

### 1. 생성 스크립트 `scripts/run_voc_rebuild_dashboard.py`
- 입력: 수집 parquet(`data/processed/<run_id>/comments_normalized.parquet`, `videos_normalized.parquet`) 또는 raw voc dataset(xlsx/csv).
- 처리: **`src/voc_rebuild` 엔진**(`analyze_rows` / `analyze_workbook_rows`)로 60컬럼 산출. **front-stage 파서 경유 금지.**
- 출력: `outputs/voc_dashboard_60/<run>/voc_dashboard_dataset.csv`(60컬럼 v2.4) + `topic_distribution.csv` + `metadata.json`(`schema_version="voc-60col-v2.4"`, `parser_version="voc-rebuild-engine"`).

### 2. 데이터 계약 로더 `src/dashboard60/data_contract.py`
60컬럼 CSV 로드 + **파생 필드**:
- **sentiment_dir(긍/부/중)**: `tee_emotion_score` 부호 우선(>0 긍 / <0 부), 0이면 `tee_success_score` 부호, 둘 다 0=중립.
- **cej_group(5그룹)**: 인지·탐색→`인지/탐색` · 결정·구매→`결정/구매` · 배송·사용준비→`배송/사용준비` · 사용→`사용` · 관리·교체→`관리/교체` · 해당없음→`해당없음`. (‘공통’ 버킷은 엔진 미도입 — 추후)
- **validity**: `topic in {N/A}` 또는 `scope_excluded`→무효 / `미분류`·캐노니컬→유효.
- **gating**: `confidence_rating in {High, Very High}` 필터 + `review_required=Y` 큐.
- enum 기준: **CEJ 9단계 + 해당없음(정상 한글)**, topic=캐노니컬 + 미분류 + N/A. (레거시 파서 enum 참조 금지)

### 3. 새 운영 앱 `src/dashboard60/app_operating.py` (Streamlit, 최소 운영 화면)
- **필터**: 제품군·브랜드·국가·CEJ (`config.DashboardSettings` 재사용).
- **개요**: topic 분포 · **감성(긍/부/중) 분포** · **문의 비율** · CEJ(5그룹) 분포.
- **드릴다운**: VoC 행(topic·감성·CEJ·entity_role·rootcause_summary·TEE) + evidence 펼침 + `confidence_rating`·`review_required` 배지.
- **신뢰도 게이팅**: 기본 **High confidence만 노출** 토글 + `review_required` 사람검토 큐. (Step 0 결과 반영: 문의·감성 우선)
- entrypoint: `streamlit run src/dashboard60/app_operating.py` (기존 `streamlit_app.py`는 그대로 두되, 운영 기본은 새 앱).

## 재사용(선택)
기존 CSS/스타일·필터 위젯·`translation.py`는 재사용 가능. **단 데이터 레이어·탭 구조는 새로 짓고 모놀리스를 상속하지 말 것.**

## 재검증 & 산출
- 60컬럼 dataset 생성 확인 + 새 앱이 그걸 소비해 개요·드릴다운 렌더 확인(**스크린샷 첨부**).
- 같은 브랜치 커밋 · **main merge / deploy 금지.**

## 이후 (Phase 2~, 별도 지시)
운영 3탭 완성(영상 분석 요약·문의/정보접근 인사이트) · 개선과제/전략 → 2차 이관 · 기존 모놀리스 관리자 park · 모듈 분해(views/gating).
