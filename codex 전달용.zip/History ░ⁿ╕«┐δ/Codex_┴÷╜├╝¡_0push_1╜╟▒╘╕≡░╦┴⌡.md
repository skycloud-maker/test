# Codex 지시서 — 0) draft push + 1) 실규모 실수집 새 엔진 검증

> **대상 브랜치**: `codex/taxonomy-redesign-draft`. **라이브(codex/voc-engine-rebuild)/main/deploy/repoint 금지.**
> 순서: 0(push) → 1(실규모 검증). 1 결과는 **Cowork가 검증(라이브 게이트)** → 통과 후 별도로 라이브 반영.

## 작업 0 — draft push
- 택소노미 재설계 변경분(`engine.py`·`schema.py`·`run_voc_rebuild_dashboard.py`·`src/dashboard60/*`·`tests/*`)만 **선별 staging → commit → push origin codex/taxonomy-redesign-draft**.
- **★main merge / production deploy / repoint 금지.** 브랜치 push만.
- commit 메시지 예: `taxonomy redesign: 제품·감성 디커플링 + product_category(원문우선) + dashboard60 61컬럼 정합 (draft)`.

## 작업 1 — 실규모 실수집 새 엔진 검증 (★라이브 전 게이트)
- **실수집 로봇청소기 댓글 100~150건**(여러 영상 섞이게 — 신규 수집 또는 보유 processed run)을 **현 draft 엔진 그대로** 실행. (파일럿=로청)
- ★LLM 배치는 2분 넘게 도는 게 정상: **백그라운드 + N건마다 진행로그 + 넉넉한 하드타임아웃, '2분 무출력=종료' 미적용.** 폴백으로 건수 줄이지 말 것. 승인 안 되면 멈추고 보고.
- **보고(행별 CSV + 요약)**:
  - `product_category` 분포(로봇청소기 비율 · 기타 사유)
  - `topic`(이유) 분포 · 로청 전용 라벨 발화율
  - **제품군-topic 오분류율** · 미분류/N/A율
  - **과발화 육안 표본**(공통 라벨이 로청으로, 또는 로청 기능어가 타 제품군으로 튀는지)
  - 행별 CSV: `comment·product_category·topic·cej·inquiry_flag·tee_emotion_score·confidence_rating·trace_summary`

## 제약 (하드)
- 같은 draft 브랜치 · **라이브/main/deploy·repoint 금지** · **엔진 로직 수정 금지(실행만)** · 표준 실행 규칙(서버 detach·재시도 2회·막히면 부분결과 보고).

## 보고
push 커밋 해시 + 실규모 행별 CSV + 지표 요약. → **Cowork가 검증 → 라이브 반영 여부 판단.**
