# Codex 지시서 — 대시보드 정합 (dashboard60 → 새 61컬럼 스키마)

> **대상 브랜치**: `codex/taxonomy-redesign-draft` (엔진 재설계가 있는 draft). **★라이브(codex/voc-engine-rebuild)/main/deploy 금지 — draft에서만 정합.**
> 목적: 택소노미 재설계로 엔진 스키마가 바뀜(topic=이유 라벨, `product_category` 신설, 감성 분리, 61컬럼). 대시보드(dashboard60)가 이를 읽도록 정합. 라이브는 나중에 별도 결정.

## 수정 (dashboard60 · data_contract + views)
1. **`product_category`를 실 컬럼으로 소비** (파생 아님). 사이드바 **제품군 필터를 `product` → `product_category`**로 전환.
2. **A 임시 플래그 은퇴**: `product_category_mismatch` 파생 + `topic_display`의 "⚠ 제품군 불일치" 제거. (택소노미 재설계로 topic에 제품이 안 박히니 불일치가 원천적으로 없음.) `review_queue`는 `review_required` 기준으로 되돌림.
3. **topic = 이유 라벨**(동선/주행·스팀·세척 성능·디자인·A/S 등)로 분포·드릴다운 표시.
4. **감성**: 기존 `sentiment_dir`/`tee_emotion` 유지(감성은 topic에서 분리됨).
5. `cej_group`·`validity`·게이팅·confidence 로직 **유지**.
6. `schema_version` 표기 **voc-61col-v2.5**로 갱신.

## 렌더 fixture
- 새 엔진 출력(예: 식기세척기 150 재생성분 또는 로청 검증 산출)을 대시보드 fixture로 사용. (커밋 fixture 교체 시 draft에만.)

## 검증
- `pytest tests/test_dashboard60_data_contract.py -q` (계약 테스트 갱신).
- 3탭 렌더(개요/영상/문의) 스크린샷 — **product_category 필터 작동 · topic(이유) 분포 표시 · 불일치 플래그 제거 · 감성 분리 반영** 확인.
- 라이브 미변경.

## 제약 (하드)
- 같은 draft 브랜치 · **라이브/main/deploy 금지** · push는 사용량 제한 풀리면 선별 staging.
- 이번은 **대시보드 정합만**(엔진 로직·택소노미 어휘 유지).
- 표준 실행 규칙: 서버 detach · 2분룰 미적용 · 재시도 2회 · 막히면 부분결과 보고.

## 보고
수정 파일 diff + 3탭 스크린샷 + 새 61컬럼 스키마 소비 확인. → Cowork 검토.
