# Codex 지시서 — guard 적용 최종 fresh 150 재실행 (라이브 직전 마무리)

## 배경
- 스팸 필터 확장(`is_operator_notice` 2신호 이상) + LLM scope 과발화 방지 guard(운영자/제휴/empty 게이트가 아니면 `normal + review_required=Y`로 되돌림)까지 코드 반영·push 완료(커밋 `00d86ab`).
- 그러나 **guard 적용 최종 fresh 150 재실행이 credit_balance_exhausted로 batch 1에서 중단**되어, guard 효과가 데이터로 미검증. dashboard fixture·스크린샷도 pre-guard 기준밖에 없음.
- OpenAI 크레딧 충전 완료. 이제 최종 재실행만 남음.

## 목표
guard 적용 상태로 **실수집 로청 150건 fresh 재실행**을 완료하고, 대시보드 fixture·스크린샷까지 갱신한다.

## 지시
- 브랜치: `codex/taxonomy-redesign-draft` (같은 draft, 초안만)
- **엔진 분석 로직(topic/감성/CEJ/inquiry/TEE/rootcause/product_category)·스팸룰·guard는 추가 수정하지 말 것.** 이미 반영된 코드 그대로 **실행만.** (혹시 버그가 보여도 고치지 말고 보고)

### 1. 최종 fresh 150 재실행
- 이전과 동일한 실수집 로청 150건(영상 메타 포함)으로 guard 적용 상태 fresh 재실행.
- 실행 방식: 백그라운드 + 25건마다 진행로그. '2분 무출력=종료' 미적용. 하드타임아웃 넉넉히. 크레딧/네트워크 문제로 막히면 재시도 2회 후 보고(폴백 축소 금지).

### 2. ★guard 효과 검증 (핵심)
pre-guard 런에서 **일반 댓글 5건이 scope_excluded로 오발화**됐다(예: "기특… ㅎㅎ", "감사합니다 도움이 정말많이됩니다", "그쳐 ㅋㅋㅋ", "선풍기는 안 하나요?", "LG야 그냥 싱크대를 만들어라"). guard가 이들을 되돌렸는지 확인:
- 이 5건 각각의 **최종 status**(scope_excluded → normal 로 되돌아왔는지)를 표로 보고.
- guard로 `normal + review_required=Y` 처리된 행 전체 목록.

### 3. 스팸 필터 재확인
- 최종 scope_excluded 목록에서 **제휴/홍보 스팸은 그대로 2건**(귀곰 고정 + 로띠끼룩)만 남았는지.
- 일반 VoC·문의·비교가 스팸으로 잘못 제외된 게 있으면 전부 나열(0이어야 함).

### 4. 회귀 확인
- product_category 로봇청소기 유지(near-100%), 제품-topic 오분류 0, 디자인/긍정 라벨 회귀 없음.
- topic 분포 · 감성 분포(긍/부/중) before(이전 positive_aspect 150)/after 비교.

### 5. fixture·스크린샷 갱신
- 대시보드 기본 fixture를 이번 guard 적용 최종 dataset으로 교체.
- 3탭 스크린샷(개요/영상/문의) 재생성.

### 6. 커밋/푸시
- draft 브랜치 commit/push.
- ★main merge / production deploy / live repoint 금지.

## 산출물
- 행별 CSV(status·product_category·topic·sentiment 포함) + guard 되돌림 5건 표 + 최종 scope_excluded 목록 + 요약 JSON + 3탭 스크린샷

## 커버 한 줄
> 같은 draft, 실행만(코드 수정 금지). guard 적용 최종 fresh 150 재실행 → 오발화 5건이 normal로 돌아왔는지 + 스팸 2건만 제외됐는지 + 회귀 0 확인 → fixture·3탭 스크린샷 갱신 → commit/push. main/deploy 금지.
