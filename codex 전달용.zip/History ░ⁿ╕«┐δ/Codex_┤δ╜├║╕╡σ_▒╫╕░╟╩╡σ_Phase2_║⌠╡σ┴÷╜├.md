# Codex 빌드 지시 — 대시보드 그린필드 Phase 2 (그대로 전달)

> 저장소: `skycloud-maker/youtube-comment-analyzer` · 브랜치: `codex/voc-engine-rebuild`
> 전제: **Phase 1 완료·검증** — `src/dashboard60/app_operating.py`가 60컬럼 실데이터로 개요(topic·감성·문의·CEJ 5그룹)·드릴다운·Evidence/Trace·신뢰도 게이팅 렌더 확인됨. 이제 **운영 화면 완성 + 정리**.

## 1. 운영 탭 구성 (단일 화면 → 3 운영 탭)
현재 단일 운영 화면을 `st.tabs`로 나눔:
- **① VoC 개요/드릴다운** (현재 화면 유지) — topic·감성(긍/부/중)·문의·CEJ 5그룹 차트 + 드릴다운 + Evidence/Trace + 게이팅.
- **② 영상 분석 요약** — `video_id`/`video_title`별 집계: 댓글 수·**부정률**·문의율·대표 VoC(상위)·영상 링크(`video_url`). 60컬럼의 video_* + 파생(sentiment_dir·validity).
- **③ 문의/정보접근 인사이트** — `inquiry_flag=Y` 필터 뷰: `inquiry_type` 분포·대표 문의 댓글·`need_signal_type` 분포.

## 2. 개선과제/전략 = 2차 이관 (대시보드에서 제외)
운영 대시보드에 **넣지 않음**(2차 분석 Agent 트랙). 필요 시 "2차 분석 대상" 안내 문구만.

## 3. 기존 모놀리스 park
- `streamlit_app.py`의 운영 기본 진입점을 **`src/dashboard60/app_operating.py`**로.
- 기존 `src/dashboard_app.py`(front-stage/shadow/legacy)는 **별도 "관리자/legacy" 진입점**(예: `app_admin.py` 또는 별도 페이지)으로 분리 — 운영 기본에서 내림. **삭제하지 말고 park**(검증·이력 참조용).

## 4. 모듈 분해
`app_operating.py` → `src/dashboard60/views/overview.py` · `views/video.py` · `views/inquiry.py` · `gating.py`(신뢰도 게이팅) · `charts.py`. `data_contract.py`는 **단일 60컬럼 로더**로 유지.

## 5. (선택) 집계 확정
- CEJ 5그룹 라벨 고정: 인지/탐색 · 결정/구매 · 배송/사용준비 · 사용 · 관리/교체 · 해당없음. (‘공통’ 버킷은 엔진 미도입 — 추후)
- 제품군 필터는 현재 `product` 기반. (브랜드 독립 `product_category` 정규화는 후속 과제로 남김)

## 재검증 & 산출
- 120건(또는 실수집) 데이터로 **3탭 렌더 스크린샷**(개요·영상·문의).
- 같은 브랜치 커밋 · push 리뷰 후 · **main merge / deploy 금지.**

## 참고 (막는 것 아님)
topic 필드는 비-로봇청소기 제품에서 캐노니컬 정확도가 낮음(예: 세제 불만이 ‘제품 평가 긍정’으로) → **topic 분포는 방향성 참고**, 정밀화는 카테고리별 택소노미(후속). 감성·문의·CEJ·드릴다운은 신뢰.
