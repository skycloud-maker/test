# Codex 야간 무인 작업 지시서 v3 (+ 아침 체크리스트)

> 목적: 사용자 취침 중, **승인/라이브 배포가 필요 없는 안전한 준비 작업만** 진행.
> ★라이브 반영(L2 merge/deploy)은 밤새 하지 않는다 — 아침에 사용자 확인 후.

---

## 공통 규칙 (전 작업)
- 모든 작업 **draft 브랜치에만**. ★live 브랜치(`codex/voc-engine-rebuild`) merge / main / production deploy / repoint **금지**.
- **OpenAI/LLM 실제 호출 금지**(크레딧·승인 리스크). L2 실제 서술 생성은 아침에. mock/코드/문서 작업만.
- 루프 방지: 서버는 detach+time-box(90초). 장기 명령 하드타임아웃. **2분 무출력=강제종료.**
- **작업당 재시도 2회 → 실패하면 SKIP하고 다음 작업 진행.** 한 작업에 매달리지 말 것.
- 각 작업 결과를 아침 보고용으로 기록. 막히면 사유 명시하고 넘어가기.

---

## [작업 1] L2 라이브 반영 "준비만" (merge/deploy 금지)
목적: 아침에 사용자가 클릭 몇 번으로 L2를 라이브에 올릴 수 있게 **분기점 확인 + 백업까지만**.
1. **분기점 확인**: `codex/l2-narrative-draft`(`ef5670c`)가 라이브 `46b8092`를 조상으로 포함하는지
   `git merge-base --is-ancestor 46b8092 ef5670c` → 결과(exit 0/1) 보고.
   - exit 0(포함)이면 아침에 바로 merge 가능.
   - exit 1(미포함)이면, `46b8092` 위로 cherry-pick한 새 브랜치 `codex/l2-narrative-rebased` 생성+검증(4탭 유지·L1 재현·테스트)+push. ★단 live merge/deploy는 하지 말 것.
2. **백업 태그**: 라이브 HEAD(`46b8092`)에 `pre-l2-live-backup-20260801-46b8092` 태그 생성+push.
3. 아침용 보고: 분기점 결과 + (필요시)rebased 브랜치명 + 백업 태그명. **merge/push-to-live/deploy는 하지 않음.**

## [작업 2] L2 코드 최종 점검 (정적, 호출 없음)
1. `l2_narrative.py`의 `_resolve_api_key()`가 st.secrets→env 순서 정확한지 재확인(코드 인용).
2. `pytest tests/test_l2_narrative.py tests/test_scoring.py -q` 재실행(F/E 없어야; 종료 hang 무시).
3. import smoke.
4. 발견 이슈 있으면 **고치지 말고 목록만** 보고(아침 판단).

## [작업 3] 개선과제 Top-N 데이터 추출 (실무자 요약용 재료)
목적: 아침에 사용자가 실무자용 한 장 요약을 만들 수 있게 **데이터만** 뽑아둠. (문서화는 Cowork가 아침에)
1. 라이브 150 dataset으로 `score_improvement_tasks` 실행 → 전체 군집 우선순위표 CSV.
2. 상위 5개 군집 각각 `top_negative_vocs(k=3)` → 대표 부정 VoC + rootcause CSV.
3. 산출물: `improvement_top5_for_report.csv` + `improvement_top5_evidence.csv` (draft 브랜치 outputs/에 저장·commit).
4. ★해석/서술/제안 생성 금지(LLM 호출 없음). 순수 집계·추출만.

## [작업 4] canonical 문서 갭 정리 (문서, 코드 무관)
목적: 데이터사전 v2.5(61컬럼)와 실제 출력(62컬럼: `product_category_source` 추가)의 차이를 **정리 메모로**.
1. 현재 엔진 실제 출력 컬럼 목록(62개)을 데이터사전 v2.5의 61컬럼과 대조.
2. 차이(추가된 `product_category_source` 등)를 `canonical_gap_notes.md`로 정리(draft outputs/에).
3. ★데이터사전 원본 파일 수정 금지 — 갭 메모만. (실제 반영은 아침에 Cowork가 v2.6으로)

## [작업 5] (선택) 대시보드 카드 UX 사전조사
목적: 아침 UX 작업 준비.
1. park된 `app_admin.py`(옛 모놀리스)에서 **카드형 KPI/차트 컴포넌트**가 있는지 조사, 있으면 어떤 것들인지 목록.
2. 새 dashboard60에 차용 가능한 후보 + 60컬럼 재바인딩 필요 지점 정리 → `card_ux_candidates.md`(draft outputs/).
3. ★코드 이식/수정 금지 — 조사·목록만.

---

## [아침 체크리스트] (기상 후 사용자+Cowork)
- [ ] 작업1: 분기점 결과 확인 → L2 라이브 merge 승인 판단(백업 태그 확인 후)
- [ ] 작업2: L2 테스트/점검 통과 여부 + 발견 이슈
- [ ] 작업3: Top5 CSV로 **실무자용 한 장 요약** 생성(Cowork)
- [ ] 작업4: canonical 갭 메모 → 데이터사전 v2.6 반영 판단
- [ ] 작업5: 카드 UX 후보 검토 → UX 다듬기 착수 판단

## ★절대 금지 (재강조)
- live 브랜치 merge / main / deploy / repoint 금지
- OpenAI 실제 호출 금지
- 데이터사전/설계서/정답지 원본 수정 금지(메모만)
- 한 작업 막히면 강행 말고 SKIP+보고

## 커버 한 줄 (사용자→Codex)
> 야간 무인: 승인·배포 필요 없는 준비만. 작업1(L2 분기점+백업만, merge/deploy 금지)·2(L2 정적점검)·3(Top5 CSV 추출, LLM 호출 없음)·4(canonical 갭 메모)·5(카드UX 조사). 전부 draft만, live/main/deploy·OpenAI호출·원본수정 금지. 막히면 재시도2회 후 SKIP+보고.
