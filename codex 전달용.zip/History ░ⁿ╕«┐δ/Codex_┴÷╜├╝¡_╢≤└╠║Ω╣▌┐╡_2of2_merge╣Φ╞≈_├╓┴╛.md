# Codex 지시서 — 라이브 반영 2단계 (merge + 배포) ★첫 라이브 터치

## 배경 — 게이트 전부 통과
draft `codex/taxonomy-redesign-draft`(최신 커밋 `d2098ed`)에서:
- 택소노미 재설계(제품·감성 디커플링) · product_category(원문우선 3계층 + 영상앵커 + source 플래그) · 긍정평가 발화 · 스팸필터 · scope guard
- 실수집 로청 150 최종 검증: product_category 로봇청소기 151/151 · 제품-topic 오분류 0 · guard 오발화 5건 normal 복귀 · 스팸 정확 제외 · 일반 VoC 회귀 0
→ **라이브 게이트 통과. 이제 기존 라이브 URL을 새 택소노미로 교체(a안).**

## 목표
기존 라이브(Streamlit Community Cloud)가 보는 브랜치에 draft를 병합하여, **회사에서 접속하던 기존 URL이 새 택소노미 대시보드로 갱신**되도록 한다.

## ★안전 규칙 (반드시 순서대로, 각 단계 결과 보고 후 다음)
되돌릴 수 있게 백업부터. 문제 생기면 즉시 멈추고 보고(자체 강행 금지).

### STEP 0 — 사전 확인·백업 (여기서 한 번 멈추고 보고)
1. **라이브가 보는 브랜치 확인**: Streamlit Cloud 앱이 어느 브랜치/파일을 배포 중인지 확인해서 보고
   (기존 라이브 = `voc-engine-rebuild` + `streamlit_app.py`로 알고 있음. 실제와 다르면 그대로 보고).
2. **백업 태그**: merge 대상(라이브) 브랜치의 현재 HEAD에 백업 태그 생성 + push
   (예: `git tag pre-taxonomy-live-backup <현재HEAD>` → push). → revert 지점 확보.
3. 여기까지 하고 **STEP 1 진행 전 결과 보고**(라이브 브랜치명 + 백업 태그명 + 현재 HEAD).

### STEP 1 — merge
4. draft(`codex/taxonomy-redesign-draft` @ `d2098ed`)를 **라이브 브랜치로 merge**.
5. 충돌 있으면 **자체 해결하지 말고 충돌 파일 목록과 함께 멈추고 보고**.
6. merge 후 라이브 브랜치에서: `pytest tests/test_voc_engine_rebuild.py tests/test_dashboard60_data_contract.py -q` 통과 확인.
7. **push**. (main은 건드리지 않음 — 라이브 브랜치만)

### STEP 2 — 배포 확인
8. Streamlit Cloud 자동 재배포가 트리거되는지 확인(수 분 소요).
9. 배포 완료 후: 앱이 정상 로드되는지 + `schema=voc-61col-v2.5` 표시 + 3탭(개요/영상/문의) 렌더 + product_category 필터 동작 확인.
10. traceback/빌드 실패 있으면 **즉시 보고**(revert 판단 위해).

### STEP 3 — 결과 보고
11. 라이브 URL + 배포 상태 + 3탭 스크린샷.
12. 백업 태그명(문제 시 revert 지점).

## ★절대 금지
- **main 브랜치 merge 금지** (라이브 브랜치만).
- production/다른 앱으로의 배포 금지.
- STEP 0 백업 없이 merge 진행 금지.
- 충돌·빌드 실패를 자체 강행으로 덮지 말 것 — 멈추고 보고.

## 커버 한 줄
> 라이브 2단계(a안). STEP0(라이브 브랜치 확인+백업 태그)부터 하고 멈춰서 보고 → 승인 후 merge→push→배포 확인→URL/스크린샷. main 금지, 충돌·실패 시 강행 말고 보고.
