# Codex 요청 지시 — 대시보드 파일 제공 (그대로 전달)

> 저장소: `skycloud-maker/youtube-comment-analyzer` · 브랜치: `codex/voc-engine-rebuild`
> 목적: 대시보드 **repoint**(front-stage-dashboard-v1 → 60컬럼 v2.4) + **코드 클리닝** 계획 수립을 위해 현재 대시보드 구성을 파악하려 합니다. **지금은 인벤토리만 — 코드 수정·push 하지 마세요.**

## 받고 싶은 것 (읽기 전용 공유)
1. **대시보드 코드** — `streamlit_app.py`, `src/dashboard_app.py`, 그리고 이들이 import하는 모듈 전부(**파일 경로 + 전체 내용** 또는 GitHub 링크).
2. **현재 소비 데이터 + 스키마** — 대시보드가 기본으로 쓰는 `raw_voc_dashboard_dataset.csv`, `raw_voc_topic_distribution.csv`의 **컬럼 헤더 전체 + 샘플 5행** + metadata(`data_source`, `schema_version`, `parser_version`, `prompt_hash`).
3. **데이터 생성 경로** — front-stage 파서 → canonical → dashboard dataset을 만드는 **코드/스크립트 경로 + 개요**(어떤 파이프라인이 그 CSV들을 생성하는지).
4. **탭 인벤토리** — 현재 탭 목록 각각이 **어떤 데이터·컬럼을 읽는지** (canonical / legacy / shadow / preview / parity 구분 포함).
5. **설정/의존성** — `requirements.txt`, 실행 방법, config·상수(컬럼명 매핑·enum 목록 등).

## 형식
- 코드: 경로 + 전체 내용(또는 커밋 링크). 데이터: 헤더 + 샘플 5행.
- **코드 변경/커밋/push 금지**(현 단계는 파악만).

## 이후 (우리가 할 일)
받으면 `엔진↔대시보드 데이터 계약 점검 v1.md` 기준으로:
- **repoint 계획**: 소스 전환(front-stage-v1 → 60컬럼 v2.4) + 컬럼명 정합(`root_cause_*`→`rootcause_*`, `time_flag`→`tee_*_score`, inquiry 단일화).
- **클리닝 계획**: 탭 keep/park/delete(1차 운영 / 관리자·검증 / 2차 이관) + 모놀리스 분해.
- **신뢰도 게이팅 UI**(문의·감성 우선 노출 + High confidence + 꼬리 사람검토) 설계.
