# Codex 지시서 — product_category 영상 앵커(3차) 추가 · ★원문 우선 유지

> **대상 브랜치**: `codex/taxonomy-redesign-draft`. **라이브/main/deploy 금지. 초안만 — Cowork 검증 후.**
> 목적: product_category 판단에 설계 3차(영상 참조)를 **fallback으로만** 추가. **영상이 원문을 덮지 않는다.**

## 수정 (product_category 도출 로직만)
1. **판단 순서(설계 준수)**: ①원문(모델명·로청 기능어·명시된 제품군) → ②parent 댓글 → ③영상(video_title/tags/description). **앞 단계에서 정해지면 멈춘다(원문 우선).**
2. **★영상 앵커 = fallback**: 원문·parent에 제품 단서가 **전혀 없어 '기타'로 빠지는 경우에만**, 해당 댓글이 달린 영상의 제품군으로 채운다.
3. **★원문에 다른 제품이 명시되면 그 제품군 유지** — 영상으로 덮지 않는다. (예: 로청 영상 댓글이라도 "삼성 식기세척기가 낫다" → 식기세척기)
4. **출처 플래그 신설**: `product_category_source` (값: `text` · `parent` · `video`). 영상에서 추론한 건 `video`로 표시 → 텍스트-확정과 구분.
5. **과발화 방지**: 영상 앵커가 원문/parent 신호를 절대 덮지 않게. 순수 노이즈(N/A) 댓글은 product_category=영상 제품군이어도 topic은 그대로 N/A 유지.

## 검증 데이터 (중요)
- **★입력은 영상 메타(video_title/video_id)가 포함된 실수집이어야 함** — 지난 원문-only 테스트로는 3차 검증 불가. **로청 리뷰 영상에서 실수집 100~150건**(신규 수집 또는 보유 processed run, video_title 포함).

## 보고 (행별 CSV + 요약)
- product_category 분포(로봇청소기 비율 ↑ 기대) + **`product_category_source` 분포(text vs parent vs video)**.
- **원문에 다른 제품이 명시된 케이스가 영상으로 안 덮였는지** 육안 표본.
- 제품-topic 오분류·과발화 여전히 0인지 · N/A/미분류율.
- 행별 CSV: `comment·product_category·product_category_source·topic·cej·inquiry_flag·tee_emotion_score·confidence_rating·trace_summary`.

## 제약 (하드)
- 같은 draft 브랜치 · **라이브/main/deploy·repoint 금지** · **product_category 도출만 손봄**(topic 어휘·감성·타 로직 유지) · 표준 실행 규칙(백그라운드·2분룰 미적용·재시도 2회·막히면 부분결과 보고).

## 보고 → Cowork
diff(3차 fallback + source 플래그) + 영상 메타 포함 실규모 행별 CSV. → Cowork 검증 → **라이브 게이트 최종 판정.**
