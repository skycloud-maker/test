"""Build a self-contained review skill; never install, upload, or include test inputs."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"shared/lib"))
from runtime_assets import runtime_bytes, runtime_transform


def build(out):
    out=Path(out).resolve()
    if out.exists() or out.is_relative_to(ROOT.resolve()):
        raise ValueError("코드 밖의 새 검토 패키지 경로를 사용하십시오.")
    allowed=[ROOT/"SKILL.md"]
    for directory in ("scripts","shared","engine","runners","skills","references"):
        allowed.extend(p for p in sorted((ROOT/directory).rglob("*")) if p.is_file()
                       and not any(x in ("__pycache__",".git",".env","evals") for x in p.parts)
                       and p.suffix not in (".pyc",".pyo"))
    manifest=[]
    for src in allowed:
        rel=src.relative_to(ROOT);dst=out/rel;dst.parent.mkdir(parents=True,exist_ok=True)
        data=runtime_bytes(src);dst.write_bytes(data)
        manifest.append({"path":rel.as_posix(),"source_sha256":hashlib.sha256(src.read_bytes()).hexdigest(),
                         "sha256":hashlib.sha256(data).hexdigest(),"transform":runtime_transform(src)})
    (out/"source_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    return {"folder":str(out),"files":len(manifest),"installed":False,"uploaded":False}


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--out",type=Path,required=True)
    try:print(json.dumps(build(p.parse_args().out),ensure_ascii=False))
    except (OSError,ValueError) as exc:print(str(exc));sys.exit(2)
