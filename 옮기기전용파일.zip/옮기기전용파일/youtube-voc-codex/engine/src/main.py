﻿"""CLI module entrypoint."""

from src.cli import main


if __name__ == "__main__":
    main()
