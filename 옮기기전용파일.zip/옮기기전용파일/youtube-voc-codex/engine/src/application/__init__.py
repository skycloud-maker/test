"""Application-layer orchestration contracts."""
