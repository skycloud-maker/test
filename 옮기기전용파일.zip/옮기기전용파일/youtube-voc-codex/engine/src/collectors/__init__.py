﻿"""Collectors package."""
