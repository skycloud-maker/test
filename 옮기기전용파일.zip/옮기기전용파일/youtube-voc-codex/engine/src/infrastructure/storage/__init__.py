"""Storage-neutral repository contracts."""
