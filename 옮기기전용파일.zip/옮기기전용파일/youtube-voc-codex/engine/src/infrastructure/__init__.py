"""Infrastructure adapters and ports."""
