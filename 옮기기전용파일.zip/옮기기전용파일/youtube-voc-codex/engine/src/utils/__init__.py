﻿"""Utility helpers."""
