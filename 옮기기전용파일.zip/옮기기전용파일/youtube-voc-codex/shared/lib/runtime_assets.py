"""Render the known historical metadata template for generated artifacts only.

The source dataset is read-only. Ordinary source files are copied byte-for-byte.
"""
from pathlib import Path
import csv
import io
from functools import lru_cache

HISTORICAL_METADATA = Path(__file__).resolve().parent.parent / "data" / "7_영상메타.csv"


@lru_cache(maxsize=2048)
def runtime_transform(path):
    return "csv-header-only" if Path(path).resolve() == HISTORICAL_METADATA.resolve() else "identity"


def runtime_bytes(path):
    path=Path(path)
    data=path.read_bytes()
    if runtime_transform(path)=="identity":return data
    header=next(csv.reader(io.StringIO(data.decode("utf-8-sig"))),None)
    if not header:raise ValueError("Historical metadata template has no header")
    output=io.StringIO(newline="")
    csv.writer(output,lineterminator="\n").writerow(header)
    return ("\ufeff"+output.getvalue()).encode("utf-8")
