"""Compatibility import for the explicitly selected Codex execution profile."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "runners" / "codex"))
from codex_profile import *  # noqa: F401,F403

import codex_profile as _profile


def __getattr__(name):
    return getattr(_profile, name)
