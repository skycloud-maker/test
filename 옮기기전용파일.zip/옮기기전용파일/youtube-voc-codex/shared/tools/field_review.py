"""Field-level blind review and human decisions. No model or network calls.

The field list follows standards/6_판정대상_컬럼분류.md D (excluding
engine-owned review_required); structural changes always need human review.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
from pathlib import Path

CONTRACT = "voc-field-review/1"
FIELDS = (
    "atomic_voc", "atomic_voc_summary", "topic", "topic_provisional",
    "topic_evidence", "topic_score", "status", "scope_exclusion_reason",
    "entity_role", "cej", "cej_evidence", "inquiry_flag", "inquiry_type",
    "need_signal_flag", "need_signal_type", "tee_time_score", "tee_time_evidence",
    "tee_effort_score", "tee_effort_evidence", "tee_emotion_score", "tee_emotion_evidence",
    "tee_success_score", "tee_success_evidence", "tee_summary", "rootcause_problem",
    "rootcause_target", "rootcause_cause", "rootcause_summary", "rootcause_score",
    "product_tags", "product_additional_info", "competitor_brand_tags",
    "competitor_product_tags", "competitor_product_additional_info",
    "confidence_topic", "confidence_cej", "confidence_inquiry", "confidence_need_signal",
    "confidence_entity_role", "confidence_score", "brand", "market", "language",
)
AUDIT = "항목별판정.csv"
DECISIONS = "항목별_실무자결정.csv"
STATE = "항목별반영_상태.json"
AUDIT_COLS = ["atomic_id", "field", "reader_1", "reader_2", "selected_value",
              "decision_status", "judge_1", "judge_2", "reason"]
DECISION_COLS = ["atomic_id", "field", "원본값", "제안값", "승인상태", "사유"]
APPROVED = {"승인", "Y", "y", "O", "o", "반영"}
REJECTED = {"반려", "N", "n", "X", "x"}


class ContractError(ValueError):
    pass


def text(value):
    return "" if value is None else str(value).strip()


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode("utf-8")).hexdigest()


def read_csv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        if not headers or len(headers) != len(set(headers)):
            raise ContractError("CSV header is missing or duplicated: " + str(path))
        rows = list(reader)
        if any(None in row or any(v is None for v in row.values()) for row in rows):
            raise ContractError("CSV row width does not match its header: " + str(path))
        return rows, headers


def load_bundle(path):
    rows, headers = read_csv(Path(path) / "raw_voc.csv")
    required = {"atomic_id", "source_id", "original_voc", "atomic_voc", "status", "topic"}
    if required - set(headers) or not rows:
        raise ContractError("Non-empty raw_voc with required source/judgment columns required")
    result = {}
    for row in rows:
        aid = text(row["atomic_id"])
        if not aid or aid in result:
            raise ContractError("Empty or duplicate atomic_id")
        result[aid] = row
    return result


def fields_for(left, right):
    return [f for f in FIELDS if f in (left or {}) or f in (right or {})]


def differences(left, right):
    if left is not None and right is not None:
        if any((field in left) != (field in right) for field in FIELDS):
            raise ContractError("Reader judgment schemas differ; complete the missing columns")
        for field in ("source_id", "original_voc", "video_id", "video_title", "reference_brand", "parent_voc_id", "comment_relation"):
            if field in left and field in right and left[field] != right[field]:
                raise ContractError("Immutable source fields differ between readers: " + field)
    return [f for f in fields_for(left, right)
            if left is None or right is None or f not in left or f not in right
            or text(left[f]) != text(right[f])]


def resolve_side(mapping, readers, side):
    if side not in ("A", "B") or side not in mapping:
        raise ContractError("Missing A/B mapping")
    target = str(mapping[side]).replace("\\", "/").rstrip("/")
    matches = [i for i, reader in enumerate(readers)
               if str(reader).replace("\\", "/").rstrip("/").split("/")[-1] == target.split("/")[-1]]
    if len(matches) != 1:
        raise ContractError("A/B mapping does not identify a unique reader")
    return matches[0]


def candidates(left, right, mapping, readers):
    a = resolve_side(mapping, readers, "A")
    b = resolve_side(mapping, readers, "B")
    if a == b:
        raise ContractError("A and B refer to the same reader")
    pair = (left, right)
    return ({f: (pair[a] or {}).get(f) for f in fields_for(left, right)},
            {f: (pair[b] or {}).get(f) for f in fields_for(left, right)})


def judge_value(judge, field, pair, mapping, readers):
    entries = judge.get("field_verdicts", {}) if judge else {}
    if not isinstance(entries, dict):
        raise ContractError("field_verdicts must be an object")
    entry = entries.get(field)
    if entry is None:
        return None, "missing field verdict"
    if not isinstance(entry, dict):
        raise ContractError("Each field verdict must be an object")
    why = text(entry.get("why"))
    choice = entry.get("verdict")
    if choice not in ("A", "B", "C", "U") or not why:
        raise ContractError("A/B/C/U verdict and field-specific why required")
    if choice == "U":
        return None, why
    if choice == "C":
        if "value" not in entry or isinstance(entry["value"], (dict, list)):
            raise ContractError("C requires an explicit scalar value (empty string is allowed)")
        value = text(entry["value"])
    else:
        row = pair[resolve_side(mapping, readers, choice)]
        if row is None or field not in row:
            return None, "selected reader has no field/row"
        value = text(row[field])
        if "value" in entry and text(entry["value"]) != value:
            raise ContractError("A/B value contradicts the mapped reader")
    quote = text(entry.get("quote"))
    if quote:
        raw = " ".join(text((pair[0] or pair[1] or {}).get(k))
                       for k in ("original_voc", "atomic_voc", "voc_cleaned"))
        if "".join(quote.split()) not in "".join(raw.split()):
            raise ContractError("Judge quote is absent from the source text")
    return value, why


def resolve_row(aid, left, right, mapping, readers, j1, j2, provisional):
    """Return a per-cell ledger; never infer a cell decision from a row verdict."""
    result = dict(provisional)
    changed = differences(left, right)
    for judge in (j1, j2):
        entries = (judge or {}).get("field_verdicts", {})
        if not isinstance(entries, dict) or set(entries) - set(changed):
            raise ContractError("Unexpected/protected/non-disputed field verdict")
    if changed and left is not None and right is not None:
        candidates(left, right, mapping, readers)  # verify private mapping before writing
    audit = []
    for field in fields_for(left, right):
        lv, rv = text((left or {}).get(field)), text((right or {}).get(field))
        value, status, why = text(result.get(field)), "pending", "reader schema/row missing"
        v1 = v2 = None
        if left is not None and right is not None and field in left and field in right:
            if lv == rv:
                value, status, why = lv, "reader_agree", "two readers agree on this field"
            else:
                v1, why1 = judge_value(j1 or {}, field, (left, right), mapping, readers)
                v2, why2 = judge_value(j2 or {}, field, (left, right), mapping, readers)
                why = why1 + " | " + why2
                if v1 is not None and v2 is not None and v1 == v2:
                    value, status = v1, "judge_agree"
        result[field] = value
        audit.append(dict(zip(AUDIT_COLS, [aid, field, lv, rv, value, status,
                                          v1 if v1 is not None else "",
                                          v2 if v2 is not None else "", why])))
    structural = left is None or right is None or any((j or {}).get("verdict") == "D" for j in (j1, j2))
    if structural:
        audit.append(dict(zip(AUDIT_COLS, [aid, "__row__", "present" if left else "absent",
                          "present" if right else "absent", "keep", "pending", "", "",
                          "row/split/merge structure requires human review; keep or omit"])))
    # These are existing contract relationships, not new business thresholds.
    issue_fields = set()
    if text(result.get("status")) == "normal" and text(result.get("scope_exclusion_reason")) not in ("", "N/A", "none"):
        issue_fields.update(("status", "scope_exclusion_reason"))
    if text(result.get("status")) == "scope_excluded" and text(result.get("topic")) not in ("", "N/A"):
        issue_fields.update(("status", "topic"))
    for prefix in ("inquiry", "need_signal"):
        if text(result.get(prefix + "_flag")) == "N" and text(result.get(prefix + "_type")) not in ("", "N/A", "none"):
            issue_fields.update((prefix + "_flag", prefix + "_type"))
    for item in audit:
        if item["field"] in issue_fields:
            item["decision_status"] = "pending"
            item["reason"] = "dependent fields conflict; human review required"
    pending = [item for item in audit if item["decision_status"] == "pending"]
    result["review_required"] = "Y" if pending else "N"
    result["review_reason"] = "항목별 미결: " + ", ".join(x["field"] for x in pending) if pending else ""
    result["decided_by"] = "field_review_pending" if pending else "field_review_agree"
    result["decided_note"] = "항목별판정.csv에 항목별 결정과 근거를 기록"
    return result, audit


def write_csv(path, rows, columns):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".field-review.tmp")
    try:
        with tmp.open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
            writer.writeheader(); writer.writerows(rows)
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink()


def save_review(bundle, audit, input_fingerprint):
    bundle = Path(bundle)
    state_path = bundle / STATE
    if state_path.exists():
        old = json.loads(state_path.read_text(encoding="utf-8"))
        if old["input_fingerprint"] != input_fingerprint or old.get("finalized"):
            raise ContractError("Existing human review belongs to another/completed run; use a new run")
    write_csv(bundle / AUDIT, audit, AUDIT_COLS)
    state = {"contract": CONTRACT, "input_fingerprint": input_fingerprint,
             "audit_sha256": hashlib.sha256((bundle / AUDIT).read_bytes()).hexdigest(),
             "review_data_sha256": hashlib.sha256((bundle / "raw_voc.csv").read_bytes()).hexdigest(),
             "finalized": False}
    state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    if not (bundle / DECISIONS).exists():
        rows = [{"atomic_id": x["atomic_id"], "field": x["field"],
                 "원본값": x["selected_value"], "제안값": "", "승인상태": "대기", "사유": ""}
                for x in audit if x["decision_status"] == "pending"]
        write_csv(bundle / DECISIONS, rows, DECISION_COLS)
    import structure_review as S
    S.create_template(bundle, input_fingerprint)


def validate_dependencies(row):
    issues = []
    if row.get("status") == "normal" and text(row.get("scope_exclusion_reason")) not in ("", "N/A", "none"):
        issues.append("normal/exclusion_reason")
    if row.get("status") == "scope_excluded" and text(row.get("topic")) not in ("", "N/A"):
        issues.append("excluded/topic")
    for prefix in ("inquiry", "need_signal"):
        if row.get(prefix + "_flag") == "N" and text(row.get(prefix + "_type")) not in ("", "N/A", "none"):
            issues.append(prefix + " flag/type")
    return issues


def finalize(root, dry_run=False):
    """Validate cell decisions and approved structure changes before writing."""
    import structure_review as S
    root=Path(root)
    bundle=root/"_판독패키지"/"_결과"/"master_final"
    if not (bundle/STATE).exists():return 0
    state=json.loads((bundle/STATE).read_text(encoding="utf-8"))
    if state.get("contract")!=CONTRACT:raise ContractError("Unknown field-review contract")
    audit_path=bundle/AUDIT
    if hashlib.sha256(audit_path.read_bytes()).hexdigest()!=state["audit_sha256"]:
        raise ContractError("Field-review ledger changed outside the review tool")
    structure_path=bundle/S.DECISIONS
    structure_sha=hashlib.sha256(structure_path.read_bytes()).hexdigest() if structure_path.exists() else None
    if state.get("finalized"):
        if (hashlib.sha256((bundle/DECISIONS).read_bytes()).hexdigest()!=state.get("decisions_sha256")
                or structure_sha!=state.get("structure_decisions_sha256")):
            raise ContractError("Human decisions changed after finalization; start a new reviewed run")
        verify_finalized(root)
        return 0
    if state.get("review_data_sha256") and hashlib.sha256((bundle/"raw_voc.csv").read_bytes()).hexdigest()!=state["review_data_sha256"]:
        raise ContractError("Current data differs from the reviewed value/source snapshot")
    audit,_=read_csv(audit_path)
    rows,columns=read_csv(bundle/"raw_voc.csv")
    by_id={x["atomic_id"]:x for x in rows}
    if len(by_id)!=len(rows):raise ContractError("Duplicate final row")
    ledger={(x["atomic_id"],x["field"]):x for x in audit}
    if len(ledger)!=len(audit):raise ContractError("Duplicate ledger key")
    if {x["atomic_id"] for x in audit}!=set(by_id):
        raise ContractError("Final row set differs from the reviewed row set")
    plan=S.plan(bundle, rows, columns, audit, state)
    retired=plan["retired"]
    pending={key for key,item in ledger.items() if item["decision_status"]=="pending"}
    decisions,_=read_csv(bundle/DECISIONS)
    approved,reasons,seen={},{},set()
    for decision in decisions:
        key=(decision.get("atomic_id"),decision.get("field"))
        if key not in pending or key in seen:raise ContractError("Unknown or duplicate human decision key")
        seen.add(key)
        if text(decision.get("원본값"))!=ledger[key]["selected_value"]:
            raise ContractError("Stale human decision original value")
        approval=text(decision.get("승인상태"))
        if approval in APPROVED:
            if not text(decision.get("사유")):raise ContractError("Approved human decision needs a reason")
            if key[0] in retired:raise ContractError("A replaced parent has competing approved cell/keep decisions")
            approved[key]=text(decision.get("제안값"));reasons[key]=text(decision.get("사유"))
        elif approval not in REJECTED|{"","대기","보류"}:raise ContractError("Unknown approval status")
    for key,item in ledger.items():
        if key[1]!="__row__" and text(by_id[key[0]].get(key[1]))!=item["selected_value"]:
            raise ContractError("Current data differs from the reviewed value")
    omitted=set()
    for (aid,field),value in approved.items():
        if field=="__row__":
            if value not in ("keep","omit"):raise ContractError("Structural decision must be keep or omit; use the approved structure form for split/merge")
            if value=="omit":omitted.add(aid)
    if any(aid in omitted and field!="__row__" for aid,field in approved):
        raise ContractError("An omitted row has competing approved field changes")
    remaining={key for key in pending-set(approved) if key[0] not in retired|omitted}
    if remaining or plan["waiting"]:
        print("실무자 결정 대기: 항목 %d건 · 구조 변경 %d건 — 반려·보류는 반영하지 않습니다" % (len(remaining),plan["waiting"]))
        return 2
    for (aid,field),value in approved.items():
        if field!="__row__":by_id[aid][field]=value
    rows=[row for row in rows if row["atomic_id"] not in retired|omitted]+plan["children"]
    if not rows:raise ContractError("No retained rows; cannot publish an empty final bundle")
    for row in rows:
        if validate_dependencies(row):raise ContractError("Human decisions contain conflicting dependent fields")
        row["review_required"],row["review_reason"]="N",""
        if any(aid==row["atomic_id"] for aid,field in approved):row["decided_by"]="field_review_human"
    columns=list(dict.fromkeys(columns+[key for row in rows for key in row]))
    if dry_run:return 0
    actions={line["parent_id"]:line["action"] for line in plan["lineage"]}
    for item in audit:
        key=(item["atomic_id"],item["field"])
        if item["atomic_id"] in retired:
            item["decision_status"]="superseded_by_"+actions[item["atomic_id"]]
            links=[x for x in plan["lineage"] if x["parent_id"]==item["atomic_id"]]
            item["reason"]="승인 구조 변경 → %s | %s" % (", ".join(sorted({x["child_id"] for x in links})),links[0]["reason"])
        elif key in approved:
            item.update(selected_value=approved[key],decision_status="human_approved",reason=reasons[key])
    audit.extend(plan["audit"])
    parents_snapshot={"contract":S.CONTRACT,"input_fingerprint":state["input_fingerprint"],
                      "parents":{aid:by_id[aid] for aid in sorted(retired)}}
    (bundle/S.PARENTS).write_text(json.dumps(parents_snapshot,ensure_ascii=False,indent=2),encoding="utf-8")
    write_csv(bundle/"raw_voc.csv",rows,columns)
    write_csv(root/"s15_master"/"raw_voc.csv",rows,columns)
    write_csv(bundle/AUDIT,audit,AUDIT_COLS)
    write_csv(bundle/S.LINEAGE,plan["lineage"],S.LINEAGE_COLS)
    write_csv(bundle/S.SUMMARY,plan["summary"],S.SUMMARY_COLS)
    state.update(finalized=True, omitted_ids=sorted(omitted),retired_ids=sorted(retired),
                 decisions_sha256=hashlib.sha256((bundle/DECISIONS).read_bytes()).hexdigest(),
                 structure_decisions_sha256=structure_sha,
                 lineage_sha256=hashlib.sha256((bundle/S.LINEAGE).read_bytes()).hexdigest(),
                 parents_sha256=hashlib.sha256((bundle/S.PARENTS).read_bytes()).hexdigest(),
                 finalized_source_sha256=S.source_digest(rows),
                 audit_sha256=hashlib.sha256((bundle/AUDIT).read_bytes()).hexdigest())
    (bundle/STATE).write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding="utf-8")
    print("확정 반영: 항목 승인 %d건 · 구조 교체 %d행 → %d행 · 최종 %d행" % (len(approved),len(retired),len(plan["children"]),len(rows)))
    return 0


def verify_finalized(root):
    root = Path(root)
    bundle = root / "_판독패키지" / "_결과" / "master_final"
    if not (bundle / STATE).exists(): return
    state = json.loads((bundle / STATE).read_text(encoding="utf-8"))
    if not state.get("finalized"):
        raise ContractError("Field review has not been finalized")
    if hashlib.sha256((bundle / AUDIT).read_bytes()).hexdigest() != state["audit_sha256"]:
        raise ContractError("Field ledger digest mismatch")
    audit, _ = read_csv(bundle / AUDIT)
    rows = load_bundle(bundle)
    import structure_review as S
    if state.get("lineage_sha256") and hashlib.sha256((bundle/S.LINEAGE).read_bytes()).hexdigest()!=state["lineage_sha256"]:
        raise ContractError("Structural lineage changed after finalization")
    if state.get("parents_sha256") and hashlib.sha256((bundle/S.PARENTS).read_bytes()).hexdigest()!=state["parents_sha256"]:
        raise ContractError("Retired parent snapshot changed after finalization")
    if state.get("finalized_source_sha256") and S.source_digest(list(rows.values()))!=state["finalized_source_sha256"]:
        raise ContractError("Immutable source context changed after finalization")
    omitted = set(state.get("omitted_ids", [])) | set(state.get("retired_ids", []))
    if set(rows) != {x["atomic_id"] for x in audit} - omitted:
        raise ContractError("Downstream processing changed the reviewed row set; lineage review required")
    for item in audit:
        if item["atomic_id"] in omitted or item["field"] == "__row__": continue
        if item["decision_status"] == "pending" or text(rows[item["atomic_id"]].get(item["field"])) != item["selected_value"]:
            raise ContractError("Downstream processing changed a confirmed field")


def records(path):
    """Read nested JSON records in either fenced markdown or JSONL."""
    source = Path(path).read_text(encoding="utf-8")
    decoder = json.JSONDecoder()
    result, i = [], 0
    while True:
        start = source.find("{", i)
        if start < 0: break
        try:
            value, end = decoder.raw_decode(source, start)
        except ValueError as exc:
            raise ContractError("Malformed JSON in supervisor record") from exc
        i = end
        if isinstance(value, dict) and value.get("atomic_id"):
            result.append(value)
    return result


def verify_export(root, path):
    """Confirm the real exported workbook preserves every finalized judgment."""
    import openpyxl
    from decimal import Decimal, InvalidOperation
    verify_finalized(root)
    bundle = Path(root) / "_판독패키지" / "_결과" / "master_final"
    audit, _ = read_csv(bundle / AUDIT)
    state = json.loads((bundle / STATE).read_text(encoding="utf-8"))
    omitted = set(state.get("omitted_ids", [])) | set(state.get("retired_ids", []))
    def equivalent(field, actual, expected):
        if text(actual) == text(expected): return True
        if field.endswith("_score"):
            try:
                a, b = Decimal(text(actual)), Decimal(text(expected))
                return a.is_finite() and b.is_finite() and a == b
            except InvalidOperation:
                pass
        return False
    book = openpyxl.load_workbook(path, read_only=True, data_only=True)
    try:
        sheet = book["raw_voc"]
        iterator = sheet.iter_rows(values_only=True)
        headers = next(iterator)
        if "atomic_id" not in headers or len(headers) != len(set(headers)):
            raise ContractError("Exported workbook has invalid headers")
        rows = {}
        for values in iterator:
            row = dict(zip(headers, values)); aid = text(row.get("atomic_id"))
            if not aid or aid in rows: raise ContractError("Exported workbook has empty/duplicate IDs")
            rows[aid] = row
        if set(rows) != {x["atomic_id"] for x in audit} - omitted:
            raise ContractError("Exported workbook row set differs from finalized data")
        for item in audit:
            if item["atomic_id"] in omitted or item["field"] == "__row__": continue
            field = item["field"]
            if field not in headers or not equivalent(field, rows[item["atomic_id"]].get(field), item["selected_value"]):
                raise ContractError("Exported workbook changed/dropped a confirmed field: " + field)
    finally:
        book.close()


def no_review_tasks(root):
    path = Path(root) / "s13_judge" / "judge_input.csv"
    if not path.is_file(): return False
    rows, headers = read_csv(path)
    return "review_contract" in headers and not rows
