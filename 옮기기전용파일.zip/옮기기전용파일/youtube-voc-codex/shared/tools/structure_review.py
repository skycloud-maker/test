"""Apply explicitly approved, lossless split/merge payloads; never classify text."""
from __future__ import annotations
import json
from pathlib import Path
import field_review as F

CONTRACT = "voc-structure-review/1"
DECISIONS = "구조변경_실무자결정.json"
LINEAGE = "구조변경_계보.csv"
SUMMARY = "구조변경_결정기록.csv"
PARENTS = "구조변경_원본보존.json"
LINEAGE_COLS = ["operation_id", "action", "parent_id", "child_id", "source_id", "parent_fingerprint", "child_fingerprint", "reason"]
SUMMARY_COLS = ["operation_id", "action", "approval", "parent_ids", "child_ids", "reason"]
INHERITED = ("source_id", "raw_row_index", "parent_voc_id", "comment_relation", "original_voc",
             "voc_cleaned", "voc_residual", "reference_brand", "market", "language",
             "source_context_summary", "status", "scope_exclusion_reason", "proposal_flag",
             "video_id", "video_title", "video_url", "product_category", "product_category_source")
SOURCE_FIELDS = ("source_id", "raw_row_index", "parent_voc_id", "comment_relation", "original_voc",
                 "reference_brand", "video_id", "video_title", "video_url")


def compact(value):
    return "".join(F.text(value).split())


def source_digest(rows):
    return F.digest({row["atomic_id"]:{k:row.get(k, "") for k in SOURCE_FIELDS} for row in rows})


def create_template(bundle, fingerprint):
    bundle=Path(bundle)
    path=bundle/DECISIONS
    if path.exists(): return
    rows=F.load_bundle(bundle)
    audit,_=F.read_csv(bundle/F.AUDIT)
    candidates=[{"atomic_id":x["atomic_id"], "row_fingerprint":F.digest(rows[x["atomic_id"]]),
                 "reason":x["reason"]} for x in audit if x["field"]=="__row__"]
    payload={"contract":CONTRACT, "input_fingerprint":fingerprint,
             "candidates":candidates, "operations":[]}
    path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")


def split_residual(parent, children):
    """Locate non-overlapping literal child spans; retain uncovered source text."""
    original=F.text(parent)
    indices=[i for i,ch in enumerate(original) if not ch.isspace()]
    normalized="".join(original[i] for i in indices)
    used=set()
    for child in children:
        needle=compact(child)
        if not needle: raise F.ContractError("A split segment cannot be empty")
        start=normalized.find(needle)
        while start>=0 and any(i in used for i in range(start,start+len(needle))):
            start=normalized.find(needle,start+1)
        if start<0: raise F.ContractError("Split text is invented, duplicated, or overlapping")
        used.update(range(start,start+len(needle)))
    covered={indices[i] for i in used}
    return " ".join("".join(ch for i,ch in enumerate(original) if i not in covered).split())


def plan(bundle, rows, columns, audit, state):
    """Validate the entire structural batch in memory before any data writes."""
    path=Path(bundle)/DECISIONS
    if not path.exists():
        return {"retired":set(),"children":[],"audit":[],"lineage":[],"summary":[],"waiting":0}
    try:
        payload=json.loads(path.read_text(encoding="utf-8"))
    except (ValueError,OSError) as exc:
        raise F.ContractError("Structural decisions are unreadable/invalid JSON") from exc
    if not isinstance(payload,dict) or payload.get("contract")!=CONTRACT or payload.get("input_fingerprint")!=state["input_fingerprint"]:
        raise F.ContractError("Structural decisions belong to another contract/run")
    operations=payload.get("operations")
    if not isinstance(operations,list): raise F.ContractError("Structural operations must be a list")
    by_id={row["atomic_id"]:row for row in rows}
    if len(by_id)!=len(rows): raise F.ContractError("Duplicate structural parent ID")
    result={"retired":set(),"children":[],"audit":[],"lineage":[],"summary":[],"waiting":0}
    op_ids=set();child_ids=set(by_id);used_indices=set()
    for row in rows:
        prefix=F.text(row.get("source_id"))+"-"
        suffix=row["atomic_id"][len(prefix):] if row["atomic_id"].startswith(prefix) else ""
        if suffix.isdigit():used_indices.add((row.get("source_id"),int(suffix)))
    for operation in operations:
        if not isinstance(operation,dict):raise F.ContractError("Structural operation must be an object")
        op_id=F.text(operation.get("operation_id"));action=operation.get("action")
        approval=F.text(operation.get("approval"));reason=F.text(operation.get("reason"))
        if not op_id or op_id in op_ids:raise F.ContractError("Empty or duplicate structural operation ID")
        op_ids.add(op_id)
        if action not in ("split","merge"):raise F.ContractError("Only split and merge operations are supported")
        parents=operation.get("parent_ids",[])
        if not isinstance(parents,list) or any(not isinstance(x,str) for x in parents):raise F.ContractError("parent_ids must be a list of IDs")
        if approval not in F.APPROVED|F.REJECTED|{"","대기","보류"}:raise F.ContractError("Unknown structural approval status")
        result["summary"].append({"operation_id":op_id,"action":action,"approval":approval,
                                  "parent_ids":json.dumps(parents,ensure_ascii=False),"child_ids":"[]","reason":reason})
        if approval not in F.APPROVED:
            if approval not in F.REJECTED:result["waiting"]+=1
            continue
        if not reason or not parents or len(parents)!=len(set(parents)) or any(aid not in by_id for aid in parents):
            raise F.ContractError("Approved structural change requires reason and unique existing parents")
        if result["retired"] & set(parents):raise F.ContractError("A parent is consumed by more than one structural operation")
        fingerprints=operation.get("parent_fingerprints")
        if not isinstance(fingerprints,dict) or set(fingerprints)!=set(parents) or any(fingerprints[aid]!=F.digest(by_id[aid]) for aid in parents):
            raise F.ContractError("Structural parent fingerprint is stale or missing")
        parent_rows=[by_id[aid] for aid in parents]
        first=parent_rows[0];sid=F.text(first.get("source_id"))
        if not sid or any(F.text(row.get("source_id"))!=sid for row in parent_rows):
            raise F.ContractError("Cannot merge different original comments")
        for key in INHERITED:
            if key in F.FIELDS or key=="voc_residual":continue
            if any(row.get(key,"")!=first.get(key,"") for row in parent_rows):
                raise F.ContractError("Structural parents have conflicting source/engine context: "+key)
        outputs=operation.get("outputs")
        if not isinstance(outputs,list) or not ((action=="split" and len(parents)==1 and len(outputs)>=2) or (action=="merge" and len(parents)>=2 and len(outputs)==1)):
            raise F.ContractError("split requires one parent/multiple outputs; merge requires multiple parents/one output")
        judged=tuple(field for field in F.FIELDS if field in columns)
        children=[]
        for output in outputs:
            if not isinstance(output,dict):raise F.ContractError("Structural output must be an object")
            aid=F.text(output.get("atomic_id"));values=output.get("values")
            suffix=aid[len(sid)+1:] if aid.startswith(sid+"-") else ""
            if not suffix.isdigit() or int(suffix)<=0 or aid in child_ids or (sid,int(suffix)) in used_indices:
                raise F.ContractError("Output ID must be a new unused source_id-index")
            if not isinstance(values,dict) or set(values)!=set(judged) or any(isinstance(v,(dict,list)) or v is None for v in values.values()):
                raise F.ContractError("Every output judgment must be explicitly supplied; protected/unknown fields forbidden")
            child={key:"" for key in columns}
            for key in INHERITED:
                if key in child:child[key]=first.get(key,"")
            child.update({key:F.text(value) for key,value in values.items()})
            if not compact(child.get("atomic_voc")):raise F.ContractError("Structural output text is empty")
            if F.validate_dependencies(child):raise F.ContractError("Structural output has contradictory dependent fields")
            child.update(atomic_id=aid, atomic_index=str(int(suffix)),
                         split_origin_atomic_id=parents[0] if action=="split" else "",
                         decided_by="field_review_human_"+action, decided_note=reason,
                         review_required="N",review_reason="",
                         trace_summary="%s_from: %s" % (action,json.dumps(parents,ensure_ascii=False)))
            children.append(child);child_ids.add(aid);used_indices.add((sid,int(suffix)))
        if action=="split":
            residual=split_residual(first.get("atomic_voc",""),[row["atomic_voc"] for row in children])
            children[0]["voc_residual"]=" ".join(x for x in (F.text(first.get("voc_residual")),residual) if x)
            for child in children[1:]:child["voc_residual"]=""
        else:
            merged=compact(children[0]["atomic_voc"])
            if merged not in compact(first.get("original_voc")) or any(compact(row.get("atomic_voc")) not in merged for row in parent_rows):
                raise F.ContractError("Merged text must retain every parent and be grounded in the original comment")
            children[0]["voc_residual"]=" ".join(dict.fromkeys(F.text(row.get("voc_residual")) for row in parent_rows if F.text(row.get("voc_residual"))))
        result["retired"].update(parents);result["children"].extend(children)
        result["summary"][-1]["child_ids"]=json.dumps([row["atomic_id"] for row in children],ensure_ascii=False)
        for child in children:
            for field in judged:
                result["audit"].append(dict(zip(F.AUDIT_COLS,[child["atomic_id"],field,"","",child[field],"human_approved","","",reason])))
            for parent in parent_rows:
                result["lineage"].append(dict(zip(LINEAGE_COLS,[op_id,action,parent["atomic_id"],child["atomic_id"],sid,F.digest(parent),F.digest(child),reason])))
    return result
