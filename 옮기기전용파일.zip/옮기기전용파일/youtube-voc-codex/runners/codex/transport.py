"""Build a Codex CLI command without starting a process or selecting another tool."""
import json
from codex_profile import ModeError


def build_command(provider, profile, resolver):
    if provider != "codex":
        raise ModeError("이 실행부는 Codex만 지원합니다. 다른 도구로 자동 전환하지 않습니다.")
    executable = resolver("codex")
    if not executable:
        raise ModeError("Codex 실행기를 찾을 수 없습니다. 다른 도구로 대체하지 않습니다.")
    command = [executable, "exec", "--json", "--ephemeral", "-s", "workspace-write", "--skip-git-repo-check"]
    if profile.get("configured_model"):
        command += ["--model", profile["configured_model"]]
    for key in ("model_reasoning_effort", "service_tier", "model_provider"):
        if profile.get(key):
            command += ["-c", key + "=" + json.dumps(profile[key])]
    return command + ["-"]
