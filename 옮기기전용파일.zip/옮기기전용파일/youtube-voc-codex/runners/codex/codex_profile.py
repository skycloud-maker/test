"""Codex-only execution identity and bounded optional human spot checks.

No model calls, classifiers, or business thresholds are defined here.
"""
from __future__ import annotations
import csv
import hashlib
import json
from pathlib import Path
import random

MODE = "codex-single/1"
INFO = "분석운영정보.json"
INFO_CSV = "분석운영정보.csv"
SAMPLE = "합의항목_표본검수.csv"
SAMPLE_STATE = "합의항목_표본기록.json"
READERS = (("판독A", "codex"), ("판독B", "codex"))
JUDGES = (("감독1", "codex"), ("감독2", "codex"))
ALIASES = {"판독A":"codex_a", "판독B":"codex_b", "감독1":"codex_judge_1", "감독2":"codex_judge_2"}
SAMPLE_COLUMNS = ["atomic_id", "atomic_voc", "검토값_JSON", "검수결과", "사유"]


class ModeError(ValueError):
    pass


def profile(sample_size=None, model=None):
    if sample_size is not None and (isinstance(sample_size, bool) or not isinstance(sample_size, int) or sample_size < 0):
        raise ModeError("표본수는 0 이상의 정수로 명시합니다. 미설정 시 표본 검수를 했다고 기록하지 않습니다.")
    if model is not None and (not isinstance(model, str) or not model.strip()):
        raise ModeError("빈 모델 이름은 사용할 수 없습니다.")
    return {"contract":MODE, "provider":"codex", "configured_model":model,
            "readers":[list(x) for x in READERS], "supervisors":[list(x) for x in JUDGES],
            "independence":"same_tool_separate_fresh_sessions", "cross_provider_validation":False,
            "human_sample_size":sample_size, "automatic_extra_rounds":0,
            "first_stage":"existing YouTube API and OpenAI API engine unchanged"}


def bind_state(state, sample_size=None, model=None):
    """Bind identity before a resume or any new state/data writes."""
    old=state.get("운영프로필")
    if old is None and any(state.get(k) for k in ("끝난단계", "조건", "조건글", "승인", "기록", "소견")):
        raise ModeError("기존 실행은 단일 모드로 전환하지 않습니다. 별도의 새 실행 폴더를 사용하십시오.")
    selected=profile(sample_size if sample_size is not None else (old or {}).get("human_sample_size"),
                     model if model is not None else (old or {}).get("configured_model"))
    if old is not None and old != selected:
        raise ModeError("운영 도구·모델·표본 계획이 기존 실행과 다릅니다. 새 실행에서 검토하십시오.")
    state["운영프로필"]=selected
    return selected


def role_alias(work):
    name=Path(work).name
    if name in ALIASES:return ALIASES[name]
    # Supervisor work directories are created by the existing third-stage tool.
    if name in ("3차 감독1", "3차 감독2"):
        return ALIASES["감독"+name[-1]]
    raise ModeError("판독·감독 역할을 확인할 수 없는 작업 폴더입니다: "+name)


def role_prompt(work, prompt):
    alias=role_alias(work)
    review=alias.startswith("codex_judge_")
    extra=("감독결과 파일의 <이름>은 %s입니다. A/B 익명 후보의 정체·매핑·이전 세션 기록을 찾지 마십시오." % alias if review else
           "판독결과_full_NN_<판독자이름>.md와 번들에서 판독자 이름은 %s, 번들 이름은 %s_bundle입니다." % (alias,alias))
    return ("[Codex 단일 운영 시험 · 별도의 새 세션]\n"
            "실제 실행 도구는 Codex이며 아래 이름은 세션 식별자입니다. 서로 다른 AI라고 기록하지 마십시오.\n"
            +extra+"\n현재 작업 폴더와 제공된 스킬·기준만 사용하고 다른 판독/감독 폴더·총괄 매핑·과거 정답을 읽지 마십시오.\n"
            "기존 지침의 Claude Code/Codex 이름 구분보다 이 실행의 세션 식별자를 적용하십시오.\n\n"+prompt)


def expected_bundle(work):
    alias=role_alias(work)
    if alias.startswith("codex_judge_"):raise ModeError("감독에게 판독 번들을 요구할 수 없습니다.")
    found=sorted((Path(work)/"_판독패키지/_결과").glob("*_bundle/raw_voc.csv"))
    if len(found)!=1 or found[0].parent.name != alias+"_bundle":
        raise ModeError("해당 세션의 번들이 하나로 확인되지 않습니다: "+alias+"_bundle")
    return found[0].parent


def write_info(root, selected):
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    data=dict(selected, accuracy_validation="not_measured", human_sample_status=("미설정" if selected["human_sample_size"] is None else "생략(0건 명시)" if selected["human_sample_size"]==0 else "별도 표본 결과 확인"))
    (root/INFO).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    with (root/INFO_CSV).open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.writer(f);w.writerow(["항목","값"])
        for key,value in data.items():w.writerow([key,json.dumps(value,ensure_ascii=False)])


def _load(path):
    with Path(path).open(encoding="utf-8-sig",newline="") as f:
        reader=csv.DictReader(f);rows=list(reader)
        if not reader.fieldnames or len(set(reader.fieldnames))!=len(reader.fieldnames) or any(None in row or None in row.values() for row in rows):
            raise ModeError("표본 검수 입력의 CSV 구조가 잘못됐습니다.")
        return rows,reader.fieldnames


def _digest(data):
    return hashlib.sha256(json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8")).hexdigest()


def make_sample(bundle, output, selected):
    """Select once, without replacement, from fully agreed rows; retain that selection."""
    n=selected["human_sample_size"]
    if n is None or n==0:return 0
    bundle=Path(bundle);output=Path(output)
    rows,_=_load(bundle/"raw_voc.csv");audit,_=_load(bundle/"항목별판정.csv")
    eligible_ids={x["atomic_id"] for x in rows}
    for item in audit:
        if item["decision_status"] not in ("reader_agree","judge_agree"):
            eligible_ids.discard(item["atomic_id"])
    if {item["atomic_id"] for item in audit} != {row["atomic_id"] for row in rows}:
        raise ModeError("표본의 원본 행과 항목별 판정 기록이 일치하지 않습니다.")
    candidates=[row for row in rows if row["atomic_id"] in eligible_ids]
    if len({row["atomic_id"] for row in rows})!=len(rows):raise ModeError("중복 ID가 있는 데이터에서 표본을 뽑지 않습니다.")
    fingerprint=_digest({"rows":rows,"audit":audit,"profile":selected})
    output.mkdir(parents=True,exist_ok=True);record=output/SAMPLE_STATE
    if record.exists():
        saved=json.loads(record.read_text(encoding="utf-8"))
        if saved["input_fingerprint"]!=fingerprint:raise ModeError("표본 입력이 바뀌었습니다. 새 검토 실행이 필요합니다.")
        validate_sample(output, require_complete=False)
        return len(saved["selected_ids"])
    if (output/SAMPLE).exists():raise ModeError("기록 없는 기존 표본 파일을 덮어쓰지 않습니다.")
    chosen=random.SystemRandom().sample(candidates,min(n,len(candidates)))
    result=[]
    for row in chosen:
        result.append({"atomic_id":row["atomic_id"],"atomic_voc":row["atomic_voc"],
                       "검토값_JSON":json.dumps(row,ensure_ascii=False,sort_keys=True),"검수결과":"미검수","사유":""})
    with (output/SAMPLE).open("w",encoding="utf-8-sig",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=SAMPLE_COLUMNS);writer.writeheader();writer.writerows(result)
    record.write_text(json.dumps({"input_fingerprint":fingerprint,"requested":n,"eligible":len(candidates),
                      "selected_ids":[x["atomic_id"] for x in chosen],
                      "immutable_cells":{x["atomic_id"]:_digest({k:x[k] for k in SAMPLE_COLUMNS[:3]}) for x in result}},ensure_ascii=False,indent=2),encoding="utf-8")
    return len(result)


def validate_sample(output, require_complete=True):
    output=Path(output);record=output/SAMPLE_STATE
    if not record.exists():raise ModeError("지정한 표본 검수의 선택 기록이 없습니다.")
    saved=json.loads(record.read_text(encoding="utf-8"));rows,cols=_load(output/SAMPLE)
    if cols!=SAMPLE_COLUMNS or len(rows)!=len(saved["selected_ids"]) or {r["atomic_id"] for r in rows}!=set(saved["selected_ids"]):
        raise ModeError("선택된 표본의 행/열/ID를 바꿀 수 없습니다.")
    for row in rows:
        if _digest({k:row[k] for k in SAMPLE_COLUMNS[:3]})!=saved["immutable_cells"][row["atomic_id"]]:raise ModeError("표본의 원문 또는 검토값이 변경됐습니다.")
        result=row["검수결과"].strip()
        if result not in ("미검수","통과","오류","보류",""):raise ModeError("알 수 없는 표본 검수 결과입니다.")
        if require_complete and (result!="통과" or not row["사유"].strip()):
            raise ModeError("표본 검수가 미완료이거나 오류가 있습니다. 범위를 자동 확대하지 않고 실무자에게 인계합니다.")
    return len(rows)
