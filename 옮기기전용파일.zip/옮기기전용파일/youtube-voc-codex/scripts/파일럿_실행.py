"""Explicit preflight/run/finalize entry for the fixed source-only pilot."""
from pathlib import Path
import argparse
import csv
import importlib.util
import json
import os
import shutil
import sys

SKILL=Path(__file__).resolve().parents[1]
REPO=SKILL if (SKILL/"shared").is_dir() else Path(__file__).resolve().parents[4]
SHARED=SKILL/"shared" if (SKILL/"shared").is_dir() else REPO/"plugin/shared"
sys.path.insert(0,str(SHARED/"lib"))
import source_pilot as P
import codex_single_mode as M


def normal_runner():
    path=P.scripts(REPO)/"한줄_돌리기.py"
    spec=importlib.util.spec_from_file_location("source_pilot_runner",path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value)
    return value


def call_once(run,role,plan,state,runner,prompt):
    if role in state["attempts"]:
        if state["attempts"][role]["status"]!="completed":raise P.PilotError("실패/중단한 세션은 자동 재시도하지 않습니다: "+role)
        result=run/role/("reader_result.json" if role.startswith("판독") else "judge_result.json")
        if not result.exists() or P.sha(result.read_bytes())!=state["attempts"][role].get("result_sha256"):
            raise P.PilotError("완료한 세션의 결과 파일이 바뀌었습니다: "+role)
        return
    if len(state["attempts"])>=plan["max_model_role_attempts"]:raise P.PilotError("승인 계획의 세션 실행 수를 초과했습니다.")
    state["attempts"][role]={"status":"attempting"};P.write_json(run/"pilot_state.json",state)
    code,answer=runner.AI돌리기("codex",run/role,prompt,run/"기록"/(role+".jsonl"),분=plan["role_timeout_minutes"])
    result=run/role/("reader_result.json" if role.startswith("판독") else "judge_result.json")
    if not code and not result.exists():code=2
    state["attempts"][role].update(status="failed" if code else "completed",exit_code=code)
    if not code:state["attempts"][role]["result_sha256"]=P.sha(result.read_bytes())
    P.write_json(run/"pilot_state.json",state)
    if code:raise P.PilotError("모델 세션이 완료되지 않았습니다. 새 시도에는 별도 검토가 필요합니다: "+role)


def run_pilot(run,approved_digest,runner=None):
    run=Path(run);plan,state,payload=P.verify(run,REPO)
    if state.get("stage")=="awaiting_human_review":
        return {"stage":state["stage"],"model_role_attempts":len(state["attempts"]),"first_stage_executed":False}
    if approved_digest!=state["plan_digest"]:raise P.PilotError("현재 실행 계획의 지문을 명시적으로 승인해야 합니다.")
    if state.get("stage") not in ("prepared_not_executed","in_progress"):
        raise P.PilotError("현재 상태에서는 모델 실행을 시작하지 않습니다.")
    state["stage"]="in_progress";P.write_json(run/"pilot_state.json",state)
    runner=runner or normal_runner()
    profile=M.profile(model=plan["model"]);profile.update(input_mode="source-only-pilot",first_stage="not_run_for_source_only_pilot", model_reasoning_effort=plan["reasoning"],service_tier="default",model_provider="openai")
    runner.운영프로필=profile
    # Pin observed settings for this child process without changing user configuration.
    original=runner.AI돌리기
    def configured(who,work,prompt,record,분=10):
        instruction="SUPERVISOR_PROMPT.md" if Path(work).name.startswith("감독") else "PROMPT.md"
        return original(who,work,prompt+"\n이 세션의 "+instruction+"를 먼저 읽고 그 파일의 결과만 작성하십시오.",record,분=분)
    runner.AI돌리기=configured
    for role in ("판독A","판독B"):
        call_once(run,role,plan,state,runner,"PROMPT.md의 원문 파일럿 판독을 수행하십시오.")
        P.make_bundle(run,role,payload)
    runtime=run/"총괄/pilot"
    code,text=runner._파이썬(P.scripts(REPO)/"총괄자리_차리기.py",run/"총괄","pilot")
    if code:raise P.PilotError("총괄 도구 준비 실패: "+text[-700:])
    M.write_info(runtime,profile)
    results=runtime/"_판독패키지/_결과";results.mkdir(parents=True,exist_ok=True)
    for role in ("판독A","판독B"):
        bundle=run/role/"_판독패키지/_결과"/(P.ALIASES[role]+"_bundle")
        destination=results/bundle.name
        if not destination.exists():shutil.copytree(bundle,destination)
        elif (destination/"raw_voc.csv").read_bytes()!=(bundle/"raw_voc.csv").read_bytes():
            raise P.PilotError("총괄에 복사된 판독 번들이 바뀌었습니다.")
    private=runtime/"_총괄만";private.mkdir(exist_ok=True)
    judge_csv=runtime/"s13_judge/judge_input.csv"
    if not judge_csv.exists():
        code,text=runner._파이썬(runtime/"make_judge_input.py",results/"codex_a_bundle",results/"codex_b_bundle",작업=runtime)
        if code:raise P.PilotError("감독 입력 생성 실패: "+text[-700:])
    mapping=runtime/"s13_judge/ab_mapping.json"
    if mapping.exists():
        if (private/"ab_mapping.json").exists():raise P.PilotError("기존 익명 매핑을 덮어쓸 수 없습니다.")
        shutil.move(str(mapping),str(private/"ab_mapping.json"))
    snapshot={"input_sha":P.sha(judge_csv.read_bytes()),"map_sha":P.sha((private/"ab_mapping.json").read_bytes())}
    if state.get("judge_snapshot") and state["judge_snapshot"]!=snapshot:raise P.PilotError("재시작 중 익명 감독 입력/매핑이 바뀌었습니다.")
    if not state.get("judge_snapshot") and any(role.startswith("감독") for role in state["attempts"]):raise P.PilotError("감독을 시작한 실행의 입력 증거가 없습니다.")
    state["judge_snapshot"]=snapshot;P.write_json(run/"pilot_state.json",state)
    incoming,_=P.F.read_csv(judge_csv)
    if incoming:
        for role in ("감독1","감독2"):
            job=run/role
            contexts={c["source"]["atomic_id"]:c["context"] for c in payload["cases"]}
            blind_items=[dict(row,source_context=contexts[row["atomic_id"]]) for row in incoming]
            P.write_json(job/"input.json",{"contract":"voc-pilot-judge/1","input_digest":plan["input_digest"],"items":blind_items,"output_constraints":plan["output_constraints"]})
            prompt=("input.json의 항목을 criteria의 기준과 원문으로 재검토하십시오. A/B의 판독 세션 정체를 찾지 마십시오.\n"
                    "judge_result.json에 {contract: voc-pilot-judge/1, input_digest: 지정값, judgments: [...]}를 작성하십시오.\n"
                    "각 judgments 항목은 atomic_id와 field_verdicts를 가지며 review_fields에 나온 모든 칸에 {verdict:A/B/C/U, why:짧은 근거, value:C일 때 명시}를 작성합니다. 불확실하면 U입니다.\n"
                    "C의 value는 input.json의 기존 스키마 허용 값/숫자 형식을 지켜야 합니다. 불확실하면 U입니다.\n"
                    "선택한 칸만 판정하고 전체 판독 묶음을 선택하지 마십시오. 다른 역할/총괄/정답 참조는 읽지 마십시오.")
            (job/"SUPERVISOR_PROMPT.md").write_text(prompt,encoding="utf-8")
            call_once(run,role,plan,state,runner,prompt)
            data=P.read_json(job/"judge_result.json")
            if data.get("contract")!="voc-pilot-judge/1" or data.get("input_digest")!=plan["input_digest"]:raise P.PilotError("감독 입력 지문 불일치")
            records=data.get("judgments")
            if not isinstance(records,list) or len(records)!=len(incoming) or {x.get("atomic_id") for x in records}!={x["atomic_id"] for x in incoming}:raise P.PilotError("감독 판정의 누락/중복/추가")
            (results/("감독결과_01_"+P.ALIASES[role]+".md")).write_text("\n".join(json.dumps(x,ensure_ascii=False) for x in records),encoding="utf-8")
    code,text=runner._파이썬(runtime/"build_master.py",results/"codex_a_bundle",results/"codex_b_bundle","--바탕","codex_a",작업=runtime)
    if code:raise P.PilotError("항목별 통합 실패: "+text[-900:])
    bundle=results/"master_final"
    # Explicit structure proposals remain human decisions rather than silent segmentation.
    audit,cols=P.F.read_csv(bundle/P.F.AUDIT);extra=[]
    for role in ("판독A","판독B"):
        proposals=P.read_json(results/(P.ALIASES[role]+"_bundle")/"pilot_structure_proposals.json")
        for proposal in proposals:
            if not any(x["atomic_id"]==proposal["atomic_id"] and x["field"]=="__row__" for x in audit+extra):
                extra.append(dict(zip(P.F.AUDIT_COLS,[proposal["atomic_id"],"__row__","present","present","keep","pending","","",proposal["reason"]])))
    if extra:
        raw_rows,raw_cols=P.F.read_csv(bundle/"raw_voc.csv")
        proposal_ids={x["atomic_id"] for x in extra}
        for row in raw_rows:
            if row["atomic_id"] in proposal_ids:
                row.update(review_required="Y",review_reason="원문 파일럿 구조 변경 제안: __row__")
        P.F.write_csv(bundle/"raw_voc.csv",raw_rows,raw_cols)
        P.F.write_csv(runtime/"s15_master/raw_voc.csv",raw_rows,raw_cols)
        field_state=P.read_json(bundle/P.F.STATE)
        P.F.save_review(bundle,audit+extra,field_state["input_fingerprint"])
        decisions,headers=P.F.read_csv(bundle/P.F.DECISIONS)
        decisions += [{"atomic_id":x["atomic_id"],"field":"__row__","원본값":"keep","제안값":"","승인상태":"대기","사유":""} for x in extra]
        P.F.write_csv(bundle/P.F.DECISIONS,decisions,headers)
        structure=P.read_json(bundle/"구조변경_실무자결정.json")
        raw=P.F.load_bundle(bundle)
        structure["candidates"] += [{"atomic_id":x["atomic_id"],"row_fingerprint":P.F.digest(raw[x["atomic_id"]]),"reason":x["reason"]} for x in extra]
        P.write_json(bundle/"구조변경_실무자결정.json",structure)
    output=run/"아웃풋1_회의에서_정할것";output.mkdir(exist_ok=True)
    for name in (P.F.AUDIT,P.F.DECISIONS,"구조변경_실무자결정.json","raw_voc.csv"):
        if (bundle/name).exists() and not (output/name).exists():shutil.copyfile(bundle/name,output/name)
    M.write_info(output,profile);P.human_template(run,payload)
    state["stage"]="awaiting_human_review";state["supervisor_role_count"]=2 if incoming else 0
    P.write_json(run/"pilot_state.json",state)
    return {"stage":state["stage"],"model_role_attempts":len(state["attempts"]),"first_stage_executed":False}


def finalize(run):
    run=Path(run);plan,state,payload=P.verify(run,REPO)
    if state.get("stage")!="awaiting_human_review":raise P.PilotError("실무자 검토 인계가 완료되지 않았습니다.")
    P.verify_human(run,payload)
    runner=normal_runner();runner.운영프로필=M.profile(model=plan["model"])
    runner.운영프로필.update(input_mode="source-only-pilot",first_stage="not_run_for_source_only_pilot",pilot_fixed_case_review_status="approved",pilot_fixed_case_review_count=3)
    state4={"운영프로필":runner.운영프로필,"끝난단계":[]}
    code=runner.사차반영(run,state4,{"이름":"pilot"})
    if code:raise P.PilotError("항목별 최종 확정은 완료되지 않았습니다.")
    final=run/"아웃풋2_최종"
    shutil.copyfile(run/"아웃풋1_회의에서_정할것/파일럿_실무자검수.csv",final/"파일럿_실무자검수.csv")
    shutil.copyfile(run/"pilot_plan.json",final/"pilot_plan.json")
    state["stage"]="finalized";P.write_json(run/"pilot_state.json",state)
    return {"stage":"finalized"}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action",choices=("preflight","run","finalize"))
    parser.add_argument("--run",type=Path,required=True)
    parser.add_argument("--approve-plan-sha",default="")
    args=parser.parse_args()
    try:
        plan,state,payload=P.verify(args.run,REPO)
        if args.action=="preflight":result={"verified":True,"stage":state['stage'],"cases":len(payload['cases']),"model":plan['model'],"plan_digest":state['plan_digest'],"model_executed":False}
        elif args.action=="run":result=run_pilot(args.run,args.approve_plan_sha)
        else:result=finalize(args.run)
        print(json.dumps(result,ensure_ascii=False,indent=2));return 0
    except (P.PilotError,P.F.ContractError,OSError,ValueError) as exc:
        print("파일럿 중단: "+str(exc));return 2

if __name__=="__main__":sys.exit(main())
