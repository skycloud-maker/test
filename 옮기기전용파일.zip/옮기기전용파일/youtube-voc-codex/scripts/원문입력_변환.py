"""Convert source-only case JSON without losing parent/video context; no model calls."""
from pathlib import Path
import argparse
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "shared/lib"))
import source_pilot as P


def convert(source, out):
    payload = P.read_json(source)
    if payload.get("contract") != P.CONTRACT or payload.get("first_stage_executed") is not False:
        raise P.PilotError("원문 파일럿 계약과 1차 미실행 상태가 필요합니다.")
    cases = payload.get("cases")
    if not isinstance(cases, list) or len(cases) != 3:
        raise P.PilotError("고정 원문 3건이 필요합니다.")
    selected = []; rows = []; parents = {}; videos = {}
    for case in cases:
        row = case["source"]; context = case["context"]
        if set(row) != set(P.SOURCE_FIELDS):
            raise P.PilotError("원천 허용 칸 외의 판단값을 포함할 수 없습니다.")
        selected.append({"case_id": case["case_id"], "input": row}); rows.append(dict(row))
        parent = context.get("parent_original_voc", "")
        if parent:
            pid = row["parent_voc_id"]
            if row["comment_relation"] != "reply" or not pid or pid == row["source_id"]:
                raise P.PilotError("부모 댓글 맥락의 관계/ID가 잘못됐습니다.")
            if pid in parents and parents[pid]["original_voc"] != parent:
                raise P.PilotError("부모 원문이 상충합니다.")
            parents[pid] = dict(row, source_id=pid, atomic_id=pid+"-context", original_voc=parent,
                                atomic_voc=parent, parent_voc_id=pid, comment_relation="parent")
        meta = context.get("video_metadata", {})
        if meta:
            if set(meta) != set(P.VIDEO_FIELDS) or meta["video_id"] != row["video_id"]:
                raise P.PilotError("영상 메타 허용 칸/ID가 잘못됐습니다.")
            if row["video_id"] in videos and videos[row["video_id"]] != meta:
                raise P.PilotError("영상 메타가 상충합니다.")
            videos[row["video_id"]] = meta
    out = Path(out)
    if out.exists():
        raise P.PilotError("기존 변환 폴더를 덮어쓰지 않습니다.")
    P.write_json(out/"inputs.json", selected)
    P.F.write_csv(out/"source_raw.csv", rows+list(parents.values()), P.SOURCE_FIELDS)
    P.F.write_csv(out/"video_meta.csv", list(videos.values()), P.VIDEO_FIELDS)
    actual, inventory = P.inspect(out/"inputs.json", out/"source_raw.csv", out/"video_meta.csv")
    if actual != cases:
        raise P.PilotError("변환 전후 원문/맥락이 달라졌습니다. 변환 산출물을 사용하지 마십시오.")
    P.write_json(out/"conversion.json", {"source_sha256":P.sha(Path(source).read_bytes()),
        "selected_cases":len(cases),"context_parent_rows":len(parents),"video_metadata_rows":len(videos),
        "source_context_roundtrip_equal":True,"first_stage_executed":False})
    return out


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source",type=Path,required=True);parser.add_argument("--out",type=Path,required=True)
    args=parser.parse_args()
    try:
        print(convert(args.source,args.out));return 0
    except (P.PilotError,P.F.ContractError,OSError,KeyError,TypeError) as exc:
        print("입력 변환 중단: "+str(exc));return 2


if __name__=="__main__":sys.exit(main())
