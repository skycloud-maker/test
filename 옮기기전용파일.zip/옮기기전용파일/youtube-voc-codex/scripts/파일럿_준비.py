"""Prepare a fixed source-only pilot; never launches a model."""
from pathlib import Path
import argparse
import json
import sys

SKILL=Path(__file__).resolve().parents[1]
REPO=SKILL if (SKILL/"shared").is_dir() else Path(__file__).resolve().parents[4]
SHARED=SKILL/"shared" if (SKILL/"shared").is_dir() else REPO/"plugin/shared"
sys.path.insert(0,str(SHARED/"lib"))
import source_pilot as P


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs",type=Path,required=True)
    parser.add_argument("--source-raw",type=Path,required=True)
    parser.add_argument("--video-meta",type=Path,required=True)
    parser.add_argument("--out",type=Path,required=True)
    parser.add_argument("--model",required=True)
    parser.add_argument("--reasoning",default="medium")
    parser.add_argument("--role-minutes",type=int,default=10)
    args=parser.parse_args()
    result=P.prepare(REPO,args.inputs,args.source_raw,args.video_meta,args.out,args.model,args.reasoning,args.role_minutes)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0

if __name__=="__main__":sys.exit(main())
