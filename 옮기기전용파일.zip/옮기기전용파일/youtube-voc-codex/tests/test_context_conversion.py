"""Context-preserving conversion and adapter code fingerprint regressions."""
from pathlib import Path
import importlib.util
import json
import pytest
import source_pilot as P
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("context_convert",ROOT/"scripts/원문입력_변환.py")
C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)


def cases():
    result=[]
    for i in range(3):
        row=dict(atomic_id=f"c{i}-01",source_id=f"c{i}",original_voc="가상 원문",atomic_voc="가상 원문",
                 parent_voc_id="parent" if i==2 else f"c{i}",comment_relation="reply" if i==2 else "parent",
                 video_id=f"v{i}",video_title="가상 영상")
        meta={k:"가상 메타" for k in P.VIDEO_FIELDS} if i==1 else {}
        if meta:meta["video_id"]=row["video_id"]
        missing=[] if meta else ["video_tags","video_description","channel_title","published_at"]
        result.append(dict(case_id=f"case-{i}",source=row,context=dict(parent_original_voc="가상 부모" if i==2 else "",
                      video_metadata=meta,missing_context=missing+["captions_not_available"])))
    return dict(contract=P.CONTRACT,input_mode="source-only-pilot",first_stage_executed=False,cases=result)


def test_roundtrip_preserves_parent_and_video_context(tmp_path):
    payload=cases();src=tmp_path/"source.json";P.write_json(src,payload)
    out=C.convert(src,tmp_path/"converted")
    restored,_=P.inspect(out/"inputs.json",out/"source_raw.csv",out/"video_meta.csv")
    assert restored==payload["cases"]
    assert P.read_json(out/"conversion.json")["context_parent_rows"]==1
    assert P.read_json(out/"conversion.json")["video_metadata_rows"]==1
    with pytest.raises(P.PilotError):C.convert(src,out)


def test_past_judgment_cannot_enter_converter(tmp_path):
    payload=cases();payload["cases"][0]["source"]["topic"]="past-label"
    src=tmp_path/"source.json";P.write_json(src,payload)
    with pytest.raises(P.PilotError):C.convert(src,tmp_path/"bad")
    assert not (tmp_path/"bad").exists()


def test_plan_fingerprints_dedicated_codex_adapter(tmp_path):
    payload=cases();src=tmp_path/"source.json";P.write_json(src,payload)
    out=C.convert(src,tmp_path/"converted")
    P.prepare(ROOT,out/"inputs.json",out/"source_raw.csv",out/"video_meta.csv",tmp_path/"prepared",model="offline-only")
    plan=P.read_json(tmp_path/"prepared/pilot_plan.json")
    assert "runners/codex/transport.py" in plan["code_sha256"]
    assert "runners/codex/codex_profile.py" in plan["code_sha256"]
