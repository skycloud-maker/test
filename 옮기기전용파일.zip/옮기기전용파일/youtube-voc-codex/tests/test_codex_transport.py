"""No model execution: tool identity and fail-closed launch selection."""
from pathlib import Path
import sys
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "runners/codex"))
from transport import build_command
from codex_profile import ModeError


def test_codex_is_selected_even_when_copilot_is_present():
    requested = []
    def resolve(name):
        requested.append(name)
        return {"codex": "fake-codex", "copilot": "fake-copilot"}.get(name)
    args = build_command("codex", {"configured_model": "test-model"}, resolve)
    assert args[0] == "fake-codex" and requested == ["codex"]
    assert "--ephemeral" in args and "resume" not in args


def test_missing_codex_cannot_fall_back_to_installed_copilot():
    requested = []
    def resolve(name):
        requested.append(name)
        return "fake-copilot" if name == "copilot" else None
    with pytest.raises(ModeError):
        build_command("codex", {}, resolve)
    assert requested == ["codex"]


def test_other_provider_cannot_launch_through_codex_adapter():
    def forbidden(name):
        pytest.fail("must not resolve another provider")
    with pytest.raises(ModeError):
        build_command("copilot", {}, forbidden)
