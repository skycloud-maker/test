"""Offline behavior checks for Codex-only routing; all model processes are fakes."""
from pathlib import Path
import csv
import importlib.util
import io
import json
import os
import shutil
import subprocess
import sys
import pytest

REPO=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(REPO/"shared/lib"))
import codex_single_mode as M


def load_runner():
    p=REPO/"scripts/한줄_돌리기.py"
    spec=importlib.util.spec_from_file_location("single_runner_test",p)
    runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
    return runner


def write_csv(path,rows,cols):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)


def test_new_and_resumed_profiles_preserve_single_identity():
    state={"끝난단계":[],"소견":[],"기록":{}}
    first=M.bind_state(state,3,"chosen-model")
    assert first["cross_provider_validation"] is False
    assert M.bind_state(state)==first
    with pytest.raises(M.ModeError):M.bind_state(state,4)
    with pytest.raises(M.ModeError):M.bind_state(state,model="different-model")
    with pytest.raises(M.ModeError):M.bind_state({"끝난단계":["2차판독"]})


@pytest.mark.parametrize("n",[-1,1.5,True])
def test_invalid_sample_budget_rejected(n):
    with pytest.raises(M.ModeError):M.profile(n)


def test_all_model_roles_launch_fresh_codex_sessions_only(tmp_path,monkeypatch):
    runner=load_runner();runner.운영프로필=M.profile(model="chosen-model")
    runner.운영프로필.update(model_reasoning_effort="medium",service_tier="default",model_provider="openai")
    calls=[]
    class Pipe:
        def write(self,data):calls[-1]["prompt"]=data.decode("utf-8")
        def close(self):pass
    class FakeProcess:
        def __init__(self,args,**kw):
            calls.append({"args":args,"cwd":kw["cwd"]});self.stdin=Pipe()
            kw["stdout"].write(json.dumps({"type":"item.completed","item":{"type":"agent_message","text":"offline fake"}}).encode())
        def wait(self,timeout):return 0
    monkeypatch.setattr(runner.subprocess,"Popen",FakeProcess)
    monkeypatch.setattr(runner.shutil,"which",lambda name:"fake-codex" if name=="codex" else None)
    assert {provider for _,provider in runner.판독자+runner.감독자}=={"codex"}
    assert runner.총괄누구=="codex"
    for name,_ in runner.판독자+runner.감독자:
        work=tmp_path/name;work.mkdir()
        code,answer=runner.AI돌리기("codex",work,"read only assigned input",tmp_path/"logs"/(name+".jsonl"))
        assert code==0 and answer=="offline fake"
    assert len(calls)==4
    for call,(role,_) in zip(calls,runner.판독자+runner.감독자):
        assert call["args"][0]=="fake-codex" and "--ephemeral" in call["args"]
        assert "resume" not in call["args"] and "--dangerously-bypass-approvals-and-sandbox" not in call["args"]
        assert call["args"][call["args"].index("--model")+1]=="chosen-model"
        for setting in ('model_reasoning_effort="medium"','service_tier="default"','model_provider="openai"'):
            assert setting in call["args"]
        assert M.ALIASES[role] in call["prompt"]
    with pytest.raises(M.ModeError):
        runner.AI돌리기("claude",tmp_path/"판독A","x",tmp_path/"logs/reject.jsonl")
    assert len(calls)==4


def test_bundle_collision_is_rejected_before_handoff(tmp_path):
    for role in ("판독A","판독B"):
        write_csv(tmp_path/role/"_판독패키지/_결과/Codex_bundle/raw_voc.csv",[{"atomic_id":"a"}],["atomic_id"])
        with pytest.raises(M.ModeError):M.expected_bundle(tmp_path/role)
    for role in ("판독A","판독B"):
        old=tmp_path/role/"_판독패키지/_결과/Codex_bundle"
        old.rename(old.with_name(M.ALIASES[role]+"_bundle"))
        assert M.expected_bundle(tmp_path/role).name==M.ALIASES[role]+"_bundle"


def test_third_stage_handoff_keeps_both_codex_bundles(tmp_path,monkeypatch):
    runner=load_runner();runtime=tmp_path/"총괄/trial";runtime.mkdir(parents=True)
    for role,_ in runner.판독자:
        write_csv(tmp_path/role/"_판독패키지/_결과"/(M.ALIASES[role]+"_bundle")/"raw_voc.csv",[{"atomic_id":role}],["atomic_id"])
    def fake_python(script,*args,**kwargs):
        if Path(script).name=="3차_준비.py":
            for name in ("3차 감독1","3차 감독2"):(runtime/"_감독폴더"/name).mkdir(parents=True)
        return 0,"offline fake"
    monkeypatch.setattr(runner,"_파이썬",fake_python)
    monkeypatch.setattr(runner,"항목별도구_확인",lambda path:None)
    runner.단계_3차준비(tmp_path,{}, {"이름":"trial"},False)
    results=runtime/"_판독패키지/_결과"
    assert {p.name for p in results.glob("*_bundle")}=={"codex_a_bundle","codex_b_bundle"}
    assert json.loads((runtime/M.INFO).read_text(encoding="utf-8"))["cross_provider_validation"] is False


def sample_bundle(tmp_path):
    b=tmp_path/"bundle"
    rows=[{"atomic_id":f"x-{i}","atomic_voc":f"가상 의견 {i}","topic":"디자인"} for i in range(6)]
    audit=[{"atomic_id":row["atomic_id"],"field":"topic","decision_status":"pending" if i==5 else "reader_agree"} for i,row in enumerate(rows)]
    write_csv(b/"raw_voc.csv",rows,list(rows[0]));write_csv(b/"항목별판정.csv",audit,list(audit[0]))
    return b


def test_bounded_sample_excludes_pending_and_resume_does_not_resample(tmp_path):
    bundle=sample_bundle(tmp_path);output=tmp_path/"meeting";profile=M.profile(3)
    assert M.make_sample(bundle,output,profile)==3
    before=(output/M.SAMPLE).read_bytes()
    assert M.make_sample(bundle,output,profile)==3
    assert before==(output/M.SAMPLE).read_bytes()
    rows,_=M._load(output/M.SAMPLE)
    assert len({r["atomic_id"] for r in rows})==3 and all(r["atomic_id"]!="x-5" for r in rows)
    with pytest.raises(M.ModeError):M.validate_sample(output)
    for row in rows:row.update(검수결과="통과",사유="원문과 항목 값을 확인")
    write_csv(output/M.SAMPLE,rows,M.SAMPLE_COLUMNS)
    assert M.validate_sample(output)==3
    rows[0]["검수결과"]="오류";write_csv(output/M.SAMPLE,rows,M.SAMPLE_COLUMNS)
    with pytest.raises(M.ModeError):M.validate_sample(output)
    assert len(M._load(output/M.SAMPLE)[0])==3


def test_changed_sample_or_source_is_rejected(tmp_path):
    bundle=sample_bundle(tmp_path);output=tmp_path/"meeting";p=M.profile(20)
    assert M.make_sample(bundle,output,p)==5
    rows,cols=M._load(output/M.SAMPLE);rows[0]["atomic_voc"]="tampered"
    write_csv(output/M.SAMPLE,rows,cols)
    with pytest.raises(M.ModeError):M.validate_sample(output)
    rows,cols=M._load(bundle/"raw_voc.csv");rows[0]["topic"]="changed";write_csv(bundle/"raw_voc.csv",rows,cols)
    with pytest.raises(M.ModeError):M.make_sample(bundle,output,p)


@pytest.mark.parametrize("n",[None,0])
def test_unconfigured_sampling_does_not_create_a_review_claim(tmp_path,n):
    p=M.profile(n);assert M.make_sample(tmp_path/"absent",tmp_path/"output",p)==0
    assert not (tmp_path/"output").exists()
    M.write_info(tmp_path,p)
    info=json.loads((tmp_path/M.INFO).read_text(encoding="utf-8"))
    assert info["accuracy_validation"]=="not_measured" and info["cross_provider_validation"] is False


def test_sample_error_stops_fourth_stage_before_any_reflection(tmp_path):
    runner=load_runner();runner.운영프로필=M.profile(1)
    b=sample_bundle(tmp_path);M.make_sample(b,tmp_path/"아웃풋1_회의에서_정할것",runner.운영프로필)
    assert runner.사차반영(tmp_path,{}, {"이름":"trial"})==2
    assert not (tmp_path/"총괄").exists()


def test_single_profile_is_preserved_in_real_final_excel(tmp_path):
    spec=importlib.util.spec_from_file_location("single_structure_fixture",REPO/"tests/test_structure_review.py")
    fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
    for source in (REPO/"shared/tools").glob("*.py"):shutil.copyfile(source,tmp_path/source.name)
    bundle,_=fixture.split_setup(tmp_path)
    (tmp_path/"s9_group").mkdir();shutil.copyfile(REPO/"shared/registry/topic_group_map.json",tmp_path/"s9_group/topic_group_map.json")
    (tmp_path/"_배포").mkdir();shutil.copyfile(REPO/"shared/common/VoC_데이터_안내.xlsx",tmp_path/"_배포/VoC_데이터_안내.xlsx")
    M.write_info(tmp_path,M.profile())
    r=subprocess.run([sys.executable,str(tmp_path/"4차_반영.py")],cwd=tmp_path,env=dict(os.environ,VOC_ENGINE=str(REPO/"engine"),PYTHONUTF8="1",PYTHONDONTWRITEBYTECODE="1"),capture_output=True,text=True,encoding="utf-8")
    assert r.returncode==0,r.stdout+r.stderr
    import openpyxl
    book=openpyxl.load_workbook(bundle/"voc_dashboard_export_bundle_2차시험본.xlsx",read_only=True,data_only=True)
    try:
        info={row[0]:row[1] for row in book["분석운영정보"].values}
        assert info["contract"]=='"codex-single/1"'
        assert info["cross_provider_validation"]=="false"
        assert info["accuracy_validation"]=='"not_measured"'
    finally:book.close()


def test_real_read_only_preflight_needs_no_claude_and_writes_nothing(tmp_path):
    runner=REPO/"scripts/한줄_돌리기.py"
    work=tmp_path/"new-run"
    env={k:v for k,v in os.environ.items() if k not in ("YOUTUBE_API_KEY","OPENAI_API_KEY")}
    env.update(PYTHONUTF8="1",PYTHONDONTWRITEBYTECODE="1")
    result=subprocess.run([sys.executable,str(runner),str(work),"--조건","검색어=가상;이름=single_offline","--확인만"],env=env,capture_output=True,text=True,encoding="utf-8")
    assert result.returncode==2,result.stdout+result.stderr
    assert "Codex 단일 운영 시험" in result.stdout
    assert "키" in result.stdout
    assert "`claude` 명령" not in result.stdout
    assert not work.exists()


def test_old_or_missing_field_ledger_cannot_enter_final_reflection(tmp_path,monkeypatch):
    runner=load_runner()
    monkeypatch.setattr(runner,"파생칸_승인",lambda p:([],[]))
    monkeypatch.setattr(runner,"인풋2_옮기기",lambda *a:pytest.fail("must stop before reading decisions"))
    assert runner.사차반영(tmp_path,{}, {"이름":"trial"})==2
    assert not (tmp_path/"총괄").exists()
