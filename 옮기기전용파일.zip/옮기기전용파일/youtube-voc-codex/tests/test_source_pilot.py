"""Source pilot I/O and whole offline handoff. No real model processes."""
from pathlib import Path
import csv
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import pytest

REPO=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(REPO/"shared/lib"))
import source_pilot as P


def load_entry():
    spec=importlib.util.spec_from_file_location("pilot_entry_test",P.scripts(REPO)/"파일럿_실행.py")
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


@pytest.fixture(scope="module")
def prepared(tmp_path_factory):
    base=tmp_path_factory.mktemp("pilot-source-fixture");cases=[];source=[]
    for i in range(1,4):
        row={"atomic_id":f"comment-{i}-01","source_id":f"comment-{i}","original_voc":f"가상 원문 {i}","atomic_voc":f"가상 원문 {i}",
             "parent_voc_id":"parent-3" if i==3 else f"comment-{i}","comment_relation":"reply" if i==3 else "parent","video_id":f"video-{i}","video_title":f"가상 영상 {i}"}
        cases.append({"case_id":f"case-{i}","input":row});source.append(dict(row,topic="NEVER_LEAK_EXPECTED_LABEL"))
    source.append(dict(source[-1],source_id="parent-3",atomic_id="parent-3-01",original_voc="가상 부모 원문"))
    P.write_json(base/"inputs.json",cases)
    P.F.write_csv(base/"raw.csv",source,list(source[0]))
    P.F.write_csv(base/"video.csv",[{"video_id":"video-2","video_title":"가상 영상 2","video_tags":"가상 태그"}],["video_id","video_title","video_tags"])
    run=base/"prepared"
    P.prepare(REPO,base/"inputs.json",base/"raw.csv",base/"video.csv",run,model="gpt-6.1-sol")
    return base,run


@pytest.fixture
def run(prepared,tmp_path):
    dest=tmp_path/"run";shutil.copytree(prepared[1],dest);return dest


def output_for(role,payload,disagree=False,structure=False):
    rows=[]
    for i,case in enumerate(payload["cases"]):
        fields={name:"" for name in P.F.FIELDS}
        fields.update(atomic_voc=case["source"]["atomic_voc"],status="normal",topic="소음/진동" if disagree and role=="판독B" and i==0 else "디자인",inquiry_flag="N",need_signal_flag="N",entity_role="unknown",cej="사용",inquiry_type="none",need_signal_type="none",brand="N/A",market="N/A",language="ko")
        schema=P.constraints(REPO)
        for key in schema["numeric_fields"]:fields[key]="0"
        for key in schema["enum_fields"]:
            if key.startswith("confidence_"):fields[key]="Low"
        rows.append({"atomic_id":case["source"]["atomic_id"],"fields":fields,"reasons":{name:"가상 시험에서 명시적으로 만든 판정 근거" for name in fields}})
    return {"contract":"voc-pilot-reader/1","reader":P.ALIASES[role],"input_digest":P.digest(payload),"rows":rows,
            "structure_proposals":[{"atomic_id":rows[0]["atomic_id"],"reason":"가상 분리 검토"}] if structure and role=="판독A" else []}


def test_source_allowlist_and_context_do_not_leak_final_labels(prepared):
    base,run=prepared;plan,state,payload=P.verify(run,REPO)
    assert len(payload["cases"])==3
    assert len({c["source"]["source_id"] for c in payload["cases"]})==3
    assert payload["cases"][2]["context"]["parent_original_voc"]=="가상 부모 원문"
    assert all(set(c["source"])==set(P.SOURCE_FIELDS) for c in payload["cases"])
    for role in P.ROLES:
        for p in (run/role).rglob("*.json"):
            assert "NEVER_LEAK_EXPECTED_LABEL" not in p.read_text(encoding="utf-8")
    assert P.read_json(run/"상태.json")["끝난단계"]==[]
    assert plan["first_stage_executed"] is False and plan["first_stage_api_calls"]==0


@pytest.mark.parametrize("problem",["label","duplicate","text-change"])
def test_invalid_or_contaminated_source_input_stops_before_preparation(prepared,tmp_path,problem):
    base,_=prepared;items=P.read_json(base/"inputs.json")
    if problem=="label":items[0]["input"]["topic"]="secret"
    elif problem=="duplicate":items[1]=items[0]
    else:items[0]["input"]["original_voc"]="invented"
    candidate=tmp_path/"inputs.json";P.write_json(candidate,items)
    with pytest.raises(P.PilotError):P.prepare(REPO,candidate,base/"raw.csv",base/"video.csv",tmp_path/"out")
    assert not (tmp_path/"out").exists()


@pytest.mark.parametrize("relative",["판독A/input.json","판독B/PROMPT.md","pilot_plan.json"])
def test_input_prompt_or_plan_tamper_blocks_verification(run,relative):
    path=run/relative;path.write_bytes(path.read_bytes()+b" \n")
    # Whitespace in JSON plans is semantically harmless; change its content instead.
    if relative=="pilot_plan.json":
        data=P.read_json(path);data["model"]="other";P.write_json(path,data)
    if relative.endswith("input.json"):
        data=P.read_json(path);data["cases"][0]["source"]["original_voc"]="changed";P.write_json(path,data)
    with pytest.raises(P.PilotError):P.verify(run,REPO)


def test_unapproved_run_makes_no_model_calls_or_state_changes(run):
    entry=load_entry();before=(run/"pilot_state.json").read_bytes()
    class NoModel:
        def AI돌리기(self,*a,**kw):pytest.fail("real call must not be attempted")
    with pytest.raises(P.PilotError):entry.run_pilot(run,"unapproved",runner=NoModel())
    assert before==(run/"pilot_state.json").read_bytes()


@pytest.mark.parametrize("problem",["missing-field","protected-field","missing-row","missing-reason","wrong-reader"])
def test_reader_must_supply_all_fields_and_only_expected_ids(run,problem):
    _,_,payload=P.verify(run,REPO);data=output_for("판독A",payload)
    if problem=="missing-field":data["rows"][0]["fields"].pop("topic")
    elif problem=="protected-field":data["rows"][0]["fields"]["source_id"]="forged"
    elif problem=="missing-row":data["rows"].pop()
    elif problem=="missing-reason":data["rows"][0]["reasons"]["topic"]=""
    else:data["reader"]="codex_b"
    path=run/"judgment.json";P.write_json(path,data)
    with pytest.raises(P.PilotError):P.read_result(path,"codex_a",payload)


@pytest.mark.parametrize("disagree,structure",[(False,False),(True,False),(False,True)])
def test_offline_real_handoff_and_bounded_fake_sessions(run,disagree,structure):
    entry=load_entry();plan,state,payload=P.verify(run,REPO);runner=entry.normal_runner();calls=[]
    def fake_model(who,work,prompt,record,분=10):
        role=Path(work).name;calls.append(role)
        assert who=="codex" and 분==10
        if role.startswith("판독"):
            P.write_json(Path(work)/"reader_result.json",output_for(role,payload,disagree,structure))
        else:
            data=P.read_json(Path(work)/"input.json");items=[]
            assert "ab_mapping" not in json.dumps(data)
            for row in data["items"]:
                fields=json.loads(row["review_fields"])
                items.append({"atomic_id":row["atomic_id"],"field_verdicts":{name:{"verdict":"A","why":"가상 익명 후보 근거 확인"} for name in fields}})
            P.write_json(Path(work)/"judge_result.json",{"contract":"voc-pilot-judge/1","input_digest":plan["input_digest"],"judgments":items})
        return 0,"synthetic fake only"
    runner.AI돌리기=fake_model
    result=entry.run_pilot(run,state["plan_digest"],runner=runner)
    assert result["stage"]=="awaiting_human_review"
    assert len(calls)==(4 if disagree else 2)
    assert P.read_json(run/"상태.json")["first_stage_executed"] is False
    bundle=run/"총괄/pilot/_판독패키지/_결과/master_final"
    assert len(P.F.load_bundle(bundle))==3
    assert (run/"아웃풋1_회의에서_정할것/파일럿_실무자검수.csv").exists()
    with pytest.raises(P.PilotError):entry.finalize(run)
    if structure:
        decisions,_=P.F.read_csv(bundle/P.F.DECISIONS)
        assert any(x["field"]=="__row__" and x["승인상태"]=="대기" for x in decisions)
    before=list(calls)
    assert entry.run_pilot(run,state["plan_digest"],runner=runner)["stage"]=="awaiting_human_review"
    assert calls==before
    if not disagree and not structure:
        human=run/"아웃풋1_회의에서_정할것/파일럿_실무자검수.csv"
        rows,cols=P.F.read_csv(human)
        for row in rows:row.update(검수결과="통과",사유="가상 데이터의 오프라인 기능 시험")
        P.F.write_csv(human,rows,cols)
        assert entry.finalize(run)["stage"]=="finalized"
        assert calls==before
        assert (run/"아웃풋2_최종/파일럿_실무자검수.csv").exists()


def test_failed_attempt_is_not_automatically_retried(run):
    entry=load_entry();plan,state,payload=P.verify(run,REPO);calls=[]
    class Failing:
        def AI돌리기(self,*args,**kw):calls.append(1);return 124,"timeout"
    with pytest.raises(P.PilotError):entry.call_once(run,"판독A",plan,state,Failing(),"fake")
    with pytest.raises(P.PilotError):entry.call_once(run,"판독A",plan,state,Failing(),"fake")
    assert len(calls)==1


def test_human_gate_covers_fixed_cases_even_if_all_readers_agree(run):
    _,_,payload=P.verify(run,REPO);P.human_template(run,payload)
    with pytest.raises(P.PilotError):P.verify_human(run,payload)
    file=run/"아웃풋1_회의에서_정할것/파일럿_실무자검수.csv";rows,cols=P.F.read_csv(file)
    for row in rows:row.update(검수결과="통과",사유="가상 확인")
    P.F.write_csv(file,rows,cols);assert P.verify_human(run,payload)==3
    rows[0]["검수결과"]="오류";P.F.write_csv(file,rows,cols)
    with pytest.raises(P.PilotError):P.verify_human(run,payload)


def test_empty_numeric_score_is_rejected_before_export(run):
    plan,_,payload=P.verify(run,REPO);data=output_for("판독A",payload)
    data["rows"][0]["fields"]["topic_score"]=""
    path=run/"reader.json";P.write_json(path,data)
    with pytest.raises(P.PilotError,match="topic_score"):
        P.read_result(path,"codex_a",payload,plan["output_constraints"])


def test_constraints_keep_secondary_enums_and_open_topics():
    values=P.constraints(REPO)
    assert "business_signal" in values["enum_fields"]["scope_exclusion_reason"]
    assert "주거 수납/공간" in values["known_topics"]
    assert values["topic_open_vocabulary"] is True and "topic" not in values["enum_fields"]
    assert values["numeric_allowed_values"]["topic_score"]==["0","1","3","5"]
