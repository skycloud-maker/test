"""Fresh role runtime must import its own Codex adapter without the source checkout."""
from pathlib import Path
import importlib.util
import json
import os
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]


def test_role_workspace_contains_working_codex_profile_and_no_historical_metadata(tmp_path):
    spec=importlib.util.spec_from_file_location("full_runtime",ROOT/"scripts/한줄_돌리기.py")
    runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
    actor=tmp_path/"role/.agents"
    runner._코덱스_공통자료(actor)
    env=dict(os.environ,PYTHONPATH=str(actor/"shared/lib"),PYTHONUTF8="1",PYTHONDONTWRITEBYTECODE="1")
    result=subprocess.run([sys.executable,"-B","-c",
        "import codex_single_mode as M; import codex_profile; import json; print(json.dumps([M.MODE,codex_profile.__file__]))"],
        cwd=tmp_path,env=env,capture_output=True,text=True,encoding="utf-8")
    assert result.returncode==0,result.stderr
    mode,profile=json.loads(result.stdout)
    assert mode=="codex-single/1" and Path(profile).is_relative_to(actor)
    assert len((actor/"shared/data/7_영상메타.csv").read_text(encoding="utf-8-sig").splitlines())==1
