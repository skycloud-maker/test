"""Observable field-level merge, human approval and isolated CLI regressions."""
from __future__ import annotations
import csv
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import pytest

REPO = Path(__file__).resolve().parents[1]
TOOLS = REPO / "shared" / "tools"
sys.path.insert(0, str(TOOLS))
import field_review as F


def row(aid="c-1", **values):
    return dict(atomic_id=aid, source_id=aid.rsplit("-",1)[0], original_voc="가격은 좋고 사용 중 소음이 큽니다",
                atomic_voc="가격은 좋고 사용 중 소음이 큽니다", voc_cleaned="가격은 좋고 사용 중 소음이 큽니다",
                video_title="가전", product_category="기타", status="normal", scope_exclusion_reason="",
                topic="가격", cej="사용", brand="N/A", review_required="N", review_reason="", **values)


def vote(**choices):
    return {"field_verdicts":{k:{"verdict":v,"why":"원문과 이 항목의 기준을 대조했다"} for k,v in choices.items()}}


def resolve(left, right, j1, j2, mapping=None, readers=("left", "right")):
    return F.resolve_row(left["atomic_id"], left, right, mapping or {"A":"left","B":"right"},
                         readers, j1, j2, right)


def stage(tmp_path, merged, ledger):
    bundle=tmp_path/"_판독패키지"/"_결과"/"master_final"
    F.write_csv(bundle/"raw_voc.csv",[merged],list(merged))
    F.write_csv(tmp_path/"s15_master"/"raw_voc.csv",[merged],list(merged))
    F.save_review(bundle,ledger,"fixture")
    return bundle


def test_hybrid_values_follow_fields_not_a_reader_bundle():
    a,b=row(),row();a.update(topic="価格A",cej="探索A",brand="brandA");b.update(topic="価格B",cej="使用B",brand="brandB")
    j=vote(topic="A",cej="B",brand="A")
    merged,ledger=resolve(a,b,j,j)
    assert (merged["topic"],merged["cej"],merged["brand"]) == (a["topic"],b["cej"],a["brand"])
    assert merged["review_required"] == "N"
    assert all(x["decision_status"]!="pending" for x in ledger)


def test_reordered_readers_keep_private_ab_mapping():
    a,b=row(),row();a["cej"]="탐색";b["cej"]="사용"
    j=vote(cej="B")
    first,_=resolve(a,b,j,j)
    second,_=F.resolve_row("c-1",b,a,{"A":"left","B":"right"},("right","left"),j,j,a)
    assert first["cej"] == second["cej"] == "사용"


def test_different_source_choices_can_agree_on_same_direct_value():
    a,b=row(),row();a["brand"]="A";b["brand"]="B"
    j1={"field_verdicts":{"brand":{"verdict":"C","value":"N/A","why":"원문에 브랜드가 없다"}}}
    merged,ledger=resolve(a,b,j1,j1)
    assert merged["brand"]=="N/A"
    assert next(x for x in ledger if x["field"]=="brand")["decision_status"]=="judge_agree"


@pytest.mark.parametrize("second",[{},vote(cej="B"),vote(cej="U")])
def test_missing_disagree_and_abstain_go_to_human(second):
    a,b=row(),row();a["cej"]="탐색"
    merged,ledger=resolve(a,b,vote(cej="A"),second)
    pending=[x["field"] for x in ledger if x["decision_status"]=="pending"]
    assert pending==["cej"]
    assert merged["review_required"]=="Y"


@pytest.mark.parametrize("status",["", "보류", "반려"])
def test_nonapproval_cannot_finalize_or_change_data(tmp_path,status):
    a,b=row(),row();a["cej"]="탐색"
    merged,ledger=resolve(a,b,vote(cej="A"),vote(cej="B"))
    bundle=stage(tmp_path,merged,ledger)
    decisions,cols=F.read_csv(bundle/F.DECISIONS)
    decisions[0].update(승인상태=status,제안값="탐색",사유="사람이 검토했다")
    F.write_csv(bundle/F.DECISIONS,decisions,cols)
    before=(bundle/"raw_voc.csv").read_bytes()
    assert F.finalize(tmp_path)==2
    assert (bundle/"raw_voc.csv").read_bytes()==before
    assert not json.loads((bundle/F.STATE).read_text(encoding="utf-8"))["finalized"]


def test_explicit_approval_updates_both_data_locations_and_detects_later_overwrite(tmp_path):
    a,b=row(),row();a["cej"]="탐색"
    merged,ledger=resolve(a,b,vote(cej="A"),vote(cej="B"))
    bundle=stage(tmp_path,merged,ledger)
    decisions,cols=F.read_csv(bundle/F.DECISIONS)
    decisions[0].update(승인상태="승인",제안값="탐색",사유="원문을 읽고 확정")
    F.write_csv(bundle/F.DECISIONS,decisions,cols)
    assert F.finalize(tmp_path)==0
    assert F.load_bundle(bundle)["c-1"]["cej"]=="탐색"
    assert (bundle/"raw_voc.csv").read_bytes()==(tmp_path/"s15_master"/"raw_voc.csv").read_bytes()
    assert F.finalize(tmp_path)==0  # idempotent resume
    rows,headers=F.read_csv(bundle/"raw_voc.csv");rows[0]["cej"]="사용"
    F.write_csv(bundle/"raw_voc.csv",rows,headers)
    with pytest.raises(F.ContractError,match="changed a confirmed"):
        F.verify_finalized(tmp_path)


def test_approved_blank_can_clear_a_field(tmp_path):
    a,b=row(),row();a["brand"]="A";b["brand"]="B"
    merged,ledger=resolve(a,b,vote(brand="A"),vote(brand="B"))
    bundle=stage(tmp_path,merged,ledger)
    decisions,cols=F.read_csv(bundle/F.DECISIONS)
    decisions[0].update(승인상태="승인",제안값="",사유="본문에 브랜드가 없음")
    F.write_csv(bundle/F.DECISIONS,decisions,cols)
    assert F.finalize(tmp_path)==0
    assert F.load_bundle(bundle)["c-1"]["brand"]==""


@pytest.mark.parametrize("mutation",["duplicate","unknown","stale","wrong_reason"])
def test_invalid_human_batch_is_rejected_without_writes(tmp_path,mutation):
    a,b=row(),row();a["cej"]="탐색"
    merged,ledger=resolve(a,b,vote(cej="A"),vote(cej="B"));bundle=stage(tmp_path,merged,ledger)
    decisions,cols=F.read_csv(bundle/F.DECISIONS)
    decisions[0].update(승인상태="승인",제안값="탐색",사유="확정 근거")
    if mutation=="duplicate":decisions.append(dict(decisions[0]))
    elif mutation=="unknown":decisions[0]["field"]="source_id"
    elif mutation=="stale":decisions[0]["원본값"]="old"
    else:decisions[0]["사유"]=""
    F.write_csv(bundle/F.DECISIONS,decisions,cols)
    before=(bundle/"raw_voc.csv").read_bytes()
    with pytest.raises(F.ContractError):F.finalize(tmp_path)
    assert (bundle/"raw_voc.csv").read_bytes()==before


def test_protected_field_and_wrong_ab_mapping_fail():
    a,b=row(),row();a["cej"]="탐색"
    with pytest.raises(F.ContractError):resolve(a,b,vote(source_id="A"),{})
    with pytest.raises(F.ContractError):resolve(a,b,{}, {},mapping={"A":"left","B":"left"})


def test_dependent_flag_type_conflict_is_not_automatic_consensus():
    a,b=row(),row();a.update(inquiry_flag="N",inquiry_type="none");b.update(inquiry_flag="Y",inquiry_type="기능")
    j=vote(inquiry_flag="A",inquiry_type="B")
    merged,ledger=resolve(a,b,j,j)
    assert {x["field"] for x in ledger if x["decision_status"]=="pending"}=={"inquiry_flag","inquiry_type"}


def test_duplicate_bundle_ids_rejected(tmp_path):
    x=row();F.write_csv(tmp_path/"raw_voc.csv",[x,x],list(x))
    with pytest.raises(F.ContractError):F.load_bundle(tmp_path)


def test_cli_prepares_non_topic_disagreement_and_no_private_mapping(tmp_path):
    for name in ("make_judge_input.py","field_review.py","check_selfcheck.py"):
        shutil.copy2(TOOLS/name,tmp_path/name)
    a,b=row(),row();a["cej"]="탐색"
    for name,data in (("left",a),("right",b)):
        F.write_csv(tmp_path/name/"raw_voc.csv",[data],list(data))
    env=dict(os.environ,PYTHONUTF8="1",PYTHONDONTWRITEBYTECODE="1")
    env.pop("VOC_얼린기준_재현",None)
    result=subprocess.run([sys.executable,str(tmp_path/"make_judge_input.py"),"left","right"],cwd=tmp_path,env=env,capture_output=True,text=True,encoding="utf-8")
    assert result.returncode==0,result.stdout+result.stderr
    inputs,_=F.read_csv(tmp_path/"s13_judge"/"judge_input.csv")
    assert len(inputs)==1 and json.loads(inputs[0]["review_fields"])==["cej"]
    assert inputs[0]["review_contract"]==F.CONTRACT
    assert "left" not in json.dumps(inputs,ensure_ascii=False) and "right" not in json.dumps(inputs,ensure_ascii=False)
    mapping=json.loads((tmp_path/"s13_judge"/"ab_mapping.json").read_text(encoding="utf-8"))
    assert set(mapping["c-1"].values())=={"left","right"}


@pytest.mark.parametrize("human_case", ["agreement", "missing", "disagree"])
def test_isolated_build_master_executes_hybrid_merge_and_real_workbook(tmp_path,monkeypatch,human_case):
    # Use the actual exporter/engine; only provider/network calls are absent.
    for p in TOOLS.glob("*.py"):shutil.copy2(p,tmp_path/p.name)
    a,b=row(),row();a.update(topic="가격/가성비",cej="탐색",brand="LG");b.update(topic="소음/진동",cej="사용",brand="N/A")
    for name,data in (("left",a),("right",b)):
        F.write_csv(tmp_path/name/"raw_voc.csv",[data],list(data))
    (tmp_path/"s13_judge").mkdir()
    (tmp_path/"s13_judge"/"ab_mapping.json").write_text(json.dumps({"c-1":{"A":"left","B":"right"}}),encoding="utf-8")
    outputs=tmp_path/"_판독패키지"/"_결과";outputs.mkdir(parents=True)
    for name in ("codex","claudecode"):
        record={"atomic_id":"c-1",**vote(topic="A",cej="B",brand="A")}
        if name == "claudecode" and human_case == "missing":
            del record["field_verdicts"]["cej"]
        elif name == "claudecode" and human_case == "disagree":
            record["field_verdicts"]["cej"]["verdict"]="A"
        (outputs/("감독결과_01_"+name+".md")).write_text(json.dumps(record,ensure_ascii=False),encoding="utf-8")
    env=dict(os.environ,VOC_ENGINE=str(REPO/"engine"),PYTHONUTF8="1",PYTHONDONTWRITEBYTECODE="1")
    env.pop("VOC_얼린기준_재현",None)
    result=subprocess.run([sys.executable,str(tmp_path/"build_master.py"),"left","right"],cwd=tmp_path,env=env,capture_output=True,text=True,encoding="utf-8")
    assert result.returncode==0,result.stdout+result.stderr
    bundle=outputs/"master_final"
    merged=F.load_bundle(bundle)["c-1"]
    assert (merged["topic"],merged["cej"],merged["brand"])==(a["topic"],b["cej"],a["brand"])
    books=list(bundle.glob("*.xlsx"));assert books,"Actual exporter did not create a workbook"
    import openpyxl
    book=openpyxl.load_workbook(books[0],read_only=True,data_only=True)
    sheet=book["raw_voc"];it=sheet.iter_rows(values_only=True);headers=next(it);data=dict(zip(headers,next(it)));book.close()
    assert data["topic"]==a["topic"] and data["cej"]==b["cej"]
    if human_case != "agreement":
        before=(bundle/"raw_voc.csv").read_bytes()
        assert F.finalize(tmp_path)==2
        assert before==(bundle/"raw_voc.csv").read_bytes()
        decisions,cols=F.read_csv(bundle/F.DECISIONS)
        assert len(decisions)==1 and decisions[0]["field"]=="cej"
        decisions[0].update(승인상태="승인",제안값="구매",사유="실무자가 원문을 보고 확정")
        F.write_csv(bundle/F.DECISIONS,decisions,cols)
    assert F.finalize(tmp_path)==0
    # Complete the real 4th-stage tools, including final Excel and dashboard-contract exporter.
    (tmp_path/"s9_group").mkdir()
    shutil.copy2(REPO/"shared/registry/topic_group_map.json",tmp_path/"s9_group/topic_group_map.json")
    (tmp_path/"_배포").mkdir()
    shutil.copy2(REPO/"shared/common/VoC_데이터_안내.xlsx",tmp_path/"_배포/VoC_데이터_안내.xlsx")
    result=subprocess.run([sys.executable,str(tmp_path/"4차_반영.py")],cwd=tmp_path,env=env,capture_output=True,text=True,encoding="utf-8")
    assert result.returncode==0,result.stdout+result.stderr
    F.verify_export(tmp_path,books[0])
    assert F.load_bundle(bundle)["c-1"]["cej"] == ("사용" if human_case == "agreement" else "구매")


def test_source_conflict_does_not_become_a_judgment():
    a,b=row(),row();b["original_voc"]="다른 원문"
    with pytest.raises(F.ContractError,match="Immutable source"):
        resolve(a,b,{}, {})


def test_no_disputed_cells_can_finalize_without_supervisors(tmp_path):
    a=row();merged,ledger=resolve(a,a,{}, {})
    stage(tmp_path,merged,ledger)
    assert F.finalize(tmp_path)==0


def test_withdrawing_all_approvals_replaces_the_meeting_copy(tmp_path):
    path=REPO/"scripts/한줄_돌리기.py"
    spec=importlib.util.spec_from_file_location("field_runner_test",path)
    runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
    base=tmp_path/"run";stage_dir=base/"총괄"/"trial"
    master=stage_dir/"_판독패키지"/"_결과"/"master_final"
    meeting=base/"아웃풋1_회의에서_정할것"
    x={"atomic_id":"c-1","field":"cej","원본값":"사용","제안값":"탐색","승인상태":"승인","사유":"확정"}
    F.write_csv(master/F.DECISIONS,[x],F.DECISION_COLS)
    F.write_csv(stage_dir/"_최종결과"/F.DECISIONS,[x],F.DECISION_COLS)
    x["승인상태"]="보류"
    F.write_csv(meeting/F.DECISIONS,[x],F.DECISION_COLS)
    runner.인풋2_옮기기(base,stage_dir)
    data,_=F.read_csv(master/F.DECISIONS)
    assert data[0]["승인상태"]=="보류"


def test_changed_decision_after_finalization_is_not_silently_ignored(tmp_path):
    a,b=row(),row();a["cej"]="탐색"
    merged,ledger=resolve(a,b,vote(cej="A"),vote(cej="B"));bundle=stage(tmp_path,merged,ledger)
    decisions,cols=F.read_csv(bundle/F.DECISIONS)
    decisions[0].update(승인상태="승인",제안값="탐색",사유="확정")
    F.write_csv(bundle/F.DECISIONS,decisions,cols)
    assert F.finalize(tmp_path)==0
    decisions[0]["제안값"]="사용"
    F.write_csv(bundle/F.DECISIONS,decisions,cols)
    with pytest.raises(F.ContractError,match="after finalization"):
        F.finalize(tmp_path)


def test_old_run_tools_are_not_accepted_by_new_runner(tmp_path):
    path=REPO/"scripts/한줄_돌리기.py"
    spec=importlib.util.spec_from_file_location("field_old_run_test",path)
    runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
    with pytest.raises(runner.멈춤,match="새 실행 자리"):
        runner.항목별도구_확인(tmp_path)


def test_missing_source_columns_and_mismatched_judgment_schemas_stop(tmp_path):
    F.write_csv(tmp_path/"raw_voc.csv",[{"atomic_id":"c-1","topic":"가격"}],["atomic_id","topic"])
    with pytest.raises(F.ContractError,match="required source"):
        F.load_bundle(tmp_path)
    a,b=row(),row();del b["cej"]
    with pytest.raises(F.ContractError,match="schemas differ"):
        resolve(a,b,{}, {})


def test_exported_workbook_tampering_is_detected(tmp_path):
    import openpyxl
    a=row();merged,ledger=resolve(a,a,{}, {});bundle=stage(tmp_path,merged,ledger)
    assert F.finalize(tmp_path)==0
    rows,headers=F.read_csv(bundle/"raw_voc.csv")
    book=openpyxl.Workbook();sheet=book.active;sheet.title="raw_voc"
    sheet.append(headers)
    for value in rows:sheet.append([value.get(c,"") for c in headers])
    path=tmp_path/"export.xlsx";book.save(path)
    F.verify_export(tmp_path,path)
    sheet.cell(2,headers.index("cej")+1,"다른 값");book.save(path);book.close()
    with pytest.raises(F.ContractError,match="changed/dropped"):
        F.verify_export(tmp_path,path)
