"""Approved split/merge preservation, lineage, and real offline exports."""
import csv
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import pytest

REPO=Path(__file__).resolve().parents[1]
TOOLS=REPO/"shared/tools"
sys.path.insert(0,str(TOOLS))
import field_review as F
import structure_review as S


def row(aid="c-01", atomic=None, original="디자인 좋아요. 소음이 큽니다."):
    return {"atomic_id":aid,"source_id":aid.rsplit("-",1)[0],"original_voc":original,
            "atomic_voc":atomic or original,"voc_cleaned":original,"voc_residual":"",
            "status":"normal","scope_exclusion_reason":"","topic":"디자인",
            "cej":"사용","brand":"N/A","product_category":"기타","video_title":"가상 검증 영상"}


def stage(root, rows):
    resolved=[];audit=[]
    for item in rows:
        merged,ledger=F.resolve_row(item["atomic_id"],item,item,{},("left","right"),{}, {},item)
        resolved.append(merged);audit.extend(ledger)
    bundle=root/"_판독패키지"/"_결과"/"master_final"
    columns=list(resolved[0])
    F.write_csv(bundle/"raw_voc.csv",resolved,columns)
    F.write_csv(root/"s15_master/raw_voc.csv",resolved,columns)
    F.save_review(bundle,audit,"test-run")
    F.write_csv(root/"s15_master/사람이볼목록.csv",[],["atomic_id","field","총괄_의견","총괄_근거"])
    return bundle


def output(parent,aid,atomic,**values):
    judgments={f:parent[f] for f in F.FIELDS if f in parent}
    judgments.update(atomic_voc=atomic,**values)
    return {"atomic_id":aid,"values":judgments}


def approve(bundle,action,parents,outputs,approval="승인"):
    payload=json.loads((bundle/S.DECISIONS).read_text(encoding="utf-8"))
    current=F.load_bundle(bundle)
    operation={"operation_id":"op1","action":action,"parent_ids":parents,
               "parent_fingerprints":{aid:F.digest(current[aid]) for aid in parents},
               "outputs":outputs,"approval":approval,"reason":"실무자가 원문과 모든 조각 판단을 확인"}
    payload["operations"]=[operation]
    (bundle/S.DECISIONS).write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
    return payload


def split_setup(root,approval="승인"):
    parent=row();bundle=stage(root,[parent])
    payload=approve(bundle,"split",[parent["atomic_id"]],
                    [output(parent,"c-02","디자인 좋아요."),output(parent,"c-03","소음이 큽니다.",topic="소음/진동")],approval)
    return bundle,payload


def test_approved_split_preserves_source_and_records_all_fields(tmp_path):
    bundle,_=split_setup(tmp_path)
    assert F.finalize(tmp_path)==0
    rows=F.load_bundle(bundle)
    assert set(rows)=={"c-02","c-03"}
    assert {x["source_id"] for x in rows.values()}=={"c"}
    assert all(x["original_voc"]==row()["original_voc"] for x in rows.values())
    audit,_=F.read_csv(bundle/F.AUDIT)
    assert all(x["decision_status"]=="superseded_by_split" for x in audit if x["atomic_id"]=="c-01")
    assert all(x["decision_status"]=="human_approved" for x in audit if x["atomic_id"]!="c-01")
    lineage,_=F.read_csv(bundle/S.LINEAGE)
    assert {(x["parent_id"],x["child_id"]) for x in lineage}=={("c-01","c-02"),("c-01","c-03")}
    F.verify_finalized(tmp_path)
    assert F.finalize(tmp_path)==0


def test_approved_merge_uses_new_id_and_keeps_both_parent_links(tmp_path):
    original="소음이 너무 큽니다."
    parents=[row("c-01","소음이",original),row("c-02","너무 큽니다.",original)]
    bundle=stage(tmp_path,parents)
    approve(bundle,"merge",[x["atomic_id"] for x in parents],[output(parents[0],"c-03",original,topic="소음/진동")])
    assert F.finalize(tmp_path)==0
    assert set(F.load_bundle(bundle))=={"c-03"}
    lineage,_=F.read_csv(bundle/S.LINEAGE)
    assert {x["parent_id"] for x in lineage}=={"c-01","c-02"}
    F.verify_finalized(tmp_path)


@pytest.mark.parametrize("approval",["", "보류", "대기"])
def test_unapproved_structure_does_not_write_any_data(tmp_path,approval):
    bundle,_=split_setup(tmp_path,approval)
    before={name:(bundle/name).read_bytes() for name in ("raw_voc.csv",F.AUDIT,F.STATE)}
    assert F.finalize(tmp_path)==2
    assert all((bundle/name).read_bytes()==data for name,data in before.items())


def test_rejected_proposal_leaves_original_rows(tmp_path):
    bundle,_=split_setup(tmp_path,"반려")
    assert F.finalize(tmp_path)==0
    assert set(F.load_bundle(bundle))=={"c-01"}
    summary,_=F.read_csv(bundle/S.SUMMARY)
    assert summary[0]["approval"]=="반려"


@pytest.mark.parametrize("problem",["missing_field","protected_field","stale_parent","reused_id","numeric_id_alias","overlap","invented_text","duplicate_parent_operation"])
def test_invalid_structural_batch_is_rejected_without_writes(tmp_path,problem):
    bundle,payload=split_setup(tmp_path)
    op=payload["operations"][0]
    if problem=="missing_field":del op["outputs"][0]["values"]["cej"]
    elif problem=="protected_field":op["outputs"][0]["values"]["original_voc"]="바뀐 원문"
    elif problem=="stale_parent":op["parent_fingerprints"]["c-01"]="wrong"
    elif problem=="reused_id":op["outputs"][0]["atomic_id"]="c-01"
    elif problem=="numeric_id_alias":op["outputs"][0]["atomic_id"]="c-001"
    elif problem=="overlap":op["outputs"][1]["values"]["atomic_voc"]="디자인 좋아요."
    elif problem=="invented_text":op["outputs"][1]["values"]["atomic_voc"]="원문에 없는 말"
    else:other=json.loads(json.dumps(op));other["operation_id"]="op2";payload["operations"].append(other)
    (bundle/S.DECISIONS).write_text(json.dumps(payload,ensure_ascii=False),encoding="utf-8")
    before=(bundle/"raw_voc.csv").read_bytes()
    with pytest.raises(F.ContractError):F.finalize(tmp_path)
    assert (bundle/"raw_voc.csv").read_bytes()==before


def test_merge_across_original_comments_is_rejected(tmp_path):
    parents=[row("c-01"),row("d-01")];bundle=stage(tmp_path,parents)
    approve(bundle,"merge",[x["atomic_id"] for x in parents],[output(parents[0],"c-02",parents[0]["atomic_voc"])])
    with pytest.raises(F.ContractError,match="different original comments"):F.finalize(tmp_path)


def test_uncovered_split_text_is_retained_once(tmp_path):
    parent=row(original="디자인 좋아요. 추가 의견도 있어요. 소음이 큽니다.")
    bundle=stage(tmp_path,[parent])
    approve(bundle,"split",["c-01"],[output(parent,"c-02","디자인 좋아요."),output(parent,"c-03","소음이 큽니다.")])
    assert F.finalize(tmp_path)==0
    rows=list(F.load_bundle(bundle).values())
    assert sum("추가 의견도 있어요." in x["voc_residual"] for x in rows)==1


def test_retired_parent_pending_values_are_replaced_by_explicit_child_judgments(tmp_path):
    parent=row();bundle=stage(tmp_path,[parent])
    audit,headers=F.read_csv(bundle/F.AUDIT)
    for item in audit:
        if item["field"]=="topic":item["decision_status"]="pending"
    F.save_review(bundle,audit,"test-run")
    # Regenerate the pending input as this helper staged an already agreed row.
    F.write_csv(bundle/F.DECISIONS,[{"atomic_id":"c-01","field":"topic","원본값":parent["topic"],"제안값":"","승인상태":"대기","사유":""}],F.DECISION_COLS)
    approve(bundle,"split",["c-01"],[output(parent,"c-02","디자인 좋아요."),output(parent,"c-03","소음이 큽니다.")])
    assert F.finalize(tmp_path)==0


def test_finalized_lineage_and_source_cannot_change_silently(tmp_path):
    bundle,_=split_setup(tmp_path);assert F.finalize(tmp_path)==0
    original=(bundle/S.LINEAGE).read_bytes();(bundle/S.LINEAGE).write_bytes(original+b"\n")
    with pytest.raises(F.ContractError,match="lineage changed"):F.verify_finalized(tmp_path)
    (bundle/S.LINEAGE).write_bytes(original)
    rows,headers=F.read_csv(bundle/"raw_voc.csv");rows[0]["original_voc"]="바뀐 원문"
    F.write_csv(bundle/"raw_voc.csv",rows,headers)
    with pytest.raises(F.ContractError,match="source context"):F.verify_finalized(tmp_path)


@pytest.mark.parametrize("action",["split","merge"])
def test_structure_through_real_fourth_stage_and_workbook(tmp_path,action):
    for source in TOOLS.glob("*.py"):shutil.copy2(source,tmp_path/source.name)
    if action=="split":bundle,_=split_setup(tmp_path);expected={"c-02","c-03"}
    else:
        original="소음이 너무 큽니다."
        parents=[row("c-01","소음이",original),row("c-02","너무 큽니다.",original)]
        bundle=stage(tmp_path,parents)
        approve(bundle,"merge",[x["atomic_id"] for x in parents],[output(parents[0],"c-03",original,topic="소음/진동")]);expected={"c-03"}
    (tmp_path/"s9_group").mkdir();shutil.copy2(REPO/"shared/registry/topic_group_map.json",tmp_path/"s9_group/topic_group_map.json")
    (tmp_path/"_배포").mkdir();shutil.copy2(REPO/"shared/common/VoC_데이터_안내.xlsx",tmp_path/"_배포/VoC_데이터_안내.xlsx")
    env=dict(os.environ,VOC_ENGINE=str(REPO/"engine"),PYTHONUTF8="1",PYTHONDONTWRITEBYTECODE="1")
    result=subprocess.run([sys.executable,str(tmp_path/"4차_반영.py")],cwd=tmp_path,env=env,capture_output=True,text=True,encoding="utf-8")
    assert result.returncode==0,result.stdout+result.stderr
    assert set(F.load_bundle(bundle))==expected
    book=bundle/"voc_dashboard_export_bundle_2차시험본.xlsx";F.verify_export(tmp_path,book)
    import openpyxl
    workbook=openpyxl.load_workbook(book,read_only=True,data_only=True)
    assert "구조변경계보" in workbook.sheetnames and "구조변경결정" in workbook.sheetnames
    workbook.close()


def test_retired_parent_full_snapshot_is_preserved(tmp_path):
    bundle,payload=split_setup(tmp_path)
    parent=F.load_bundle(bundle)["c-01"]
    assert F.finalize(tmp_path)==0
    snapshot=json.loads((bundle/S.PARENTS).read_text(encoding="utf-8"))
    assert snapshot["parents"]["c-01"]==parent
    assert F.digest(snapshot["parents"]["c-01"])==payload["operations"][0]["parent_fingerprints"]["c-01"]


def test_structural_approval_withdrawal_reaches_authoritative_original(tmp_path):
    path=REPO/"scripts/한줄_돌리기.py"
    spec=importlib.util.spec_from_file_location("structure_runner",path)
    runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
    root=tmp_path/"run";work=root/"총괄/trial";bundle,payload=split_setup(work)
    original=work/"_최종결과"/S.DECISIONS;original.parent.mkdir();original.write_text(json.dumps(payload,ensure_ascii=False),encoding="utf-8")
    payload["operations"][0]["approval"]="보류"
    meeting=root/"아웃풋1_회의에서_정할것";meeting.mkdir()
    (meeting/S.DECISIONS).write_text(json.dumps(payload,ensure_ascii=False),encoding="utf-8")
    runner.인풋2_옮기기(root,work)
    assert json.loads((bundle/S.DECISIONS).read_text(encoding="utf-8"))["operations"][0]["approval"]=="보류"
    assert F.finalize(work)==2


def test_missing_metadata_stops_without_altering_existing_file(tmp_path):
    spec=importlib.util.spec_from_file_location("metadata_guard",TOOLS/"데이터_넣기.py")
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    target=tmp_path/"runtime/판독패키지/7_영상메타.csv";target.parent.mkdir(parents=True)
    target.write_text("video_id,video_title\nold_video,old_title\n",encoding="utf-8")
    before=target.read_bytes()
    with pytest.raises(ValueError,match="기존 영상 파일은 변경하지 않고"):
        module.영상메타_갈아끼우기(tmp_path/"input/analysis.xlsx",tmp_path/"runtime")
    assert target.read_bytes()==before
